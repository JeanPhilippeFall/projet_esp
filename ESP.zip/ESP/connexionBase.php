<?php
 try{
    $espaceEtu = new PDO('mysql:host=localhost;dbname=espaceetu', 'root', '', array(PDO::ATTR_ERRMODE=> PDO::ERRMODE_EXCEPTION));
    }
    catch(Exception $e)
    {
        die('ERROR : '.$e->getMessage());

}   

?>