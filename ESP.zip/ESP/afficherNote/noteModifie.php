<?php
session_start();

	include '../connexionBase.php';
	
	$modif= $espaceEtu->prepare("UPDATE  note SET Cc=:cc,Ds=:ds,Tp=:tp WHERE IdEtu=:idetu ");
 	$rs=$modif->execute(array(
 						'cc'=>$_REQUEST['cc'],
						'ds'=>$_REQUEST['ds'],
						'tp'=>$_REQUEST['tp'],
						'idetu'=>$_SESSION['IdEtu']
						
				));
 	unset($_SESSION['IdEtu']);
 	if ($rs) {
 		$_SESSION['insert']="modification reussie.";
 	}
 	header("location: afficheEleveNote.php");


?>