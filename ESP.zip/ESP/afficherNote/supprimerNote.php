<?php
session_start();
include '../connexionBase.php';
	$IdEtu=$_GET['IdEtu'];
	$modif= $espaceEtu->query("DELETE FROM  note WHERE IdEtu='".$IdEtu."' ");

	if ($modif) {
 		$_SESSION['sup']="Suppression reussie.";
 	}
 	header("location: afficheEleveNote.php");

?>