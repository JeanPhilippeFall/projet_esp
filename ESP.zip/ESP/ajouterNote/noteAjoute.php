<?php
session_start();
include '../connexionBase.php';
if (isset($_REQUEST['choix'])) {
	if ($_REQUEST['choixMatiere']=="" || $_REQUEST['choixEvaluation']=="") {
		$_SESSION['nomComplet']="Choisir une matiere et evaluation.";
		header("Location: ajouterNote.php");
}
	if ($_REQUEST['note']>="0" && $_REQUEST['note']<="20" ) {
		$Mat=$espaceEtu->query("SELECT IdEc FROM ec where Matiere='".$_REQUEST['choixMatiere']."' ");
		$rw=$Mat->fetch();
		$not=$espaceEtu->query("SELECT * FROM note where IdEtu='".$_SESSION['idetu']."' ");
		if($row=$not->fetch()){
			if ($_REQUEST['choixEvaluation']=="Cc") {
				
			
			$not=$espaceEtu->prepare("UPDATE note SET Cc=:cc  where IdEtu=:idetu ");
			$rs= $not->execute(array(
				           	"cc"=> $_REQUEST['note'],
				           	"idetu"=> $_SESSION['idetu']
				           	
				           		));
		}
		if ($_REQUEST['choixEvaluation']=="Ds") {
				
			
			$not=$espaceEtu->prepare("UPDATE note SET Ds=:ds  where IdEtu=:idetu ");
			$rs= $not->execute(array(
				           	"ds"=> $_REQUEST['note'],
				           	"idetu"=> $_SESSION['idetu']
				           	
				           		));
		}
		if ($_REQUEST['choixEvaluation']=="Tp") {
				
			
			$not=$espaceEtu->prepare("UPDATE note SET Tp=:tp  where IdEtu=:idetu ");
			$rs= $not->execute(array(
				           	"tp"=> $_REQUEST['note'],
				           	"idetu"=> $_SESSION['idetu']
				           	
				           		));
		}


	}else{
		if ($_REQUEST['choixEvaluation']=="Tp") {
		$not=$espaceEtu->prepare("INSERT INTO note (Tp,IdEc,IdEtu) VALUES(:tp,:idec,:idetu) ");
		$inser=$not->execute(array(
 		"tp" => $_REQUEST['note'],
 		"idec" => $rw['IdEc'],
 		"idetu" => $_SESSION['idetu']
 	));
		}
		if ($_REQUEST['choixEvaluation']=="Cc") {
		$not=$espaceEtu->prepare("INSERT INTO note (Cc,IdEc,IdEtu) VALUES(:cc,:idec,:idetu) ");
		$inser=$not->execute(array(
 		"cc" => $_REQUEST['note'],
 		"idec" => $rw['IdEc'],
 		"idetu" => $_SESSION['idetu']
 	));

		}
		if ($_REQUEST['choixEvaluation']=="Ds") {
		$not=$espaceEtu->prepare("INSERT INTO note (Ds,IdEc,IdEtu) VALUES(:ds,:idec,:idetu) ");
		$inser=$not->execute(array(
 		"ds" => $_REQUEST['note'],
 		"idec" => $rw['IdEc'],
 		"idetu" => $_SESSION['idetu']
 	));
		}
		
	
	}
		$_SESSION['insertion']="insertion reussie.";
	}else{
		$_SESSION['note']="note invalide.";
		header("Location: ajouterNote.php");
	}
}

header("Location: ajouterNote.php");
?>