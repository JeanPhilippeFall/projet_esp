<?php
session_start();
include '../connexionBase.php';
if (isset($_REQUEST['choixMatiere'])&&isset($_REQUEST['choixDate'])) {
    if ($_REQUEST['choixMatiere']==""|| $_REQUEST['choixDate']=="") {
        $_SESSION['msg']="Choisir une matiere et une Date";
        header("location: saisirAbsence.php");
    }
    $_SESSION['choixMatiere']=$_REQUEST['choixMatiere'];
    $_SESSION['choixDate']=$_REQUEST['choixDate'];
 } 

 $idClas=$espaceEtu->query("SELECT IdEc FROM ec where Matiere='".$_SESSION['choixMatiere']."' ");
				$r=$idClas->fetch();
		$not=$espaceEtu->prepare("INSERT INTO seancedecours (dat,IdEc) VALUES(:dat,:idec) ");
		$inser=$not->execute(array(
 		"dat" => $_SESSION['choixDate'],
 		"idec" => $r['IdEc']
 	));
		$IdSeance=$espaceEtu->query("SELECT IdSeance FROM seancedecours where IdEc='".$r['IdEc']."' and dat='".$_SESSION['choixDate']."' ");
		$rsSeance=$IdSeance->fetch();
		$not=$espaceEtu->prepare("INSERT INTO absence (IdSeance,IdEtu) VALUES(:IdSeance,:IdEtu) ");
		$inser=$not->execute(array(
 		"IdSeance" => $rsSeance['IdSeance'],
 		"IdEtu" => $_SESSION['IdEtuabs']
 	));
 	$_SESSION['msg2']="Insertion Reussie.";	
 	header("location: saisirAbsence.php");
?>