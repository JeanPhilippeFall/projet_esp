<?php 
session_start();
include '../connexionBase.php';
if (isset($_REQUEST['choixClasse'])&&isset($_REQUEST['choixDepartement'])) {
    if ($_REQUEST['choixClasse']==""||$_REQUEST['choixDepartement']=="") {
        $_SESSION['msg']="Choisir un departement et une classe";
        header("location: choixClasseAbsence.php");
    }
    $_SESSION['choixClasse']=$_REQUEST['choixClasse'];
    $_SESSION['choixDepartement']=$_REQUEST['choixDepartement'];
 }   
    

 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> ajouter absence</title>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../css/font-awesome.min.css">
	<link rel="stylesheet" href="../css/animate.css">
	<link href="../css/animate.min.css" rel="stylesheet"> 
	<link href="../css/style.css" rel="stylesheet" />	
	<link rel="stylesheet" type="text/css" href="../css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="../Accueil.html"><h1>ESP</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
                    <li role="presentation">
                        <a href="../Accueil.html" >Accueil</a></li>
                        <li role="presentation"><a href="" >Note</a>
                        <ul class="soumenu">
                            <li><a href="../ajouterNote/choixClasseNote.php">Ajouter</a></li>
                           
                            <li><a href="../afficherNote/classeAfficherNote.php">Afficher</a>
                            </li>
                            </ul>
                    </li>
                    <li role="presentation">
                        <a href="" class="active">Absence</a>
                        <ul  class="soumenu">
                        <li><a href="../ajouterAbsence/choixClasseAbsence.php">Ajouter</a></li>
                            
                            <li><a href="../afficherAbsence/classeAfficherAbsence.php">Afficher</a></li>
                        </ul>
                    </li>
                    <li role="presentation">
                        <a href="../deconnexion.php">Deconnexion</a>
                    </li>   
                        </ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
			
 			<?php
 			$idept=$espaceEtu->query("SELECT IdDep FROM departement where nom='".$_SESSION['choixDepartement']."' ");
    $row=$idept->fetch();
            $Etu=$espaceEtu->query("SELECT * FROM etudiant where IdClasse IN (SELECT IdClasse FROM classe where nom='".$_SESSION['choixClasse']."' and IdDep='".$row['IdDep']."') ");
           
 			
              
                //$class=$espaceEtu->query('SELECT nom FROM classe');
              ?>
 			<div class="mov">
            <form action="saisirAbsence.php" method="POST">
 			 <table border="2" style="color: black;" class="table table-striped">
            <tr  style="background-color: #65aaf0;">
            <th>Nom</th><th>Prenom</th><th>naissance</th><th>Choix</th>
            </tr>
            <?php				
 		while($row=$Etu->fetch()){?>
	       <tr>
                <td><?php  echo $row['Nom'];?></td>
                <td> <?php echo $row['Prenom'];?></td>
                 <td><?php  echo $row['DatNes'];?></td>
                 <td><a style=" color: blue;" href="saisirAbsence.php?IdEtuabs=<?php echo $row['IdEtu']; ?>">Choisir</a></td>
            </tr>
		<?php }?></table>
        </form>
        </div>
  
<div class="p"></div>
  </body>
</html>