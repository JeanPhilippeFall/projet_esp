<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=espaceetu', 'root', '');
	//echo 'connexion à la base de données réussie';
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
?>