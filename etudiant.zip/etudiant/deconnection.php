<?php  
session_unset();
session_destroy();
header("Location: http://localhost/projet/accueil/accueil.html");

?>