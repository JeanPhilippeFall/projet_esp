<?php
session_start();
include '../connexionBase.php';

$FileError=$_FILES["fichier"]["error"];
if (isset($_FILES['fichier']['name'])) {
  $extension = strtolower(substr($_FILES['fichier']['name'],-3));
    
            if ($extension == "pdf") {
                move_uploaded_file($_FILES['fichier']['tmp_name'],"d/".$_FILES['fichier']['name']);
                 $FileName = "d/".$_FILES['fichier']['name'];
                  $Typ=$_REQUEST['libelle'];
         
            }else{
              $_SESSION['msg']="Veuiller choisir un bon format";
               header("Location: fichierEtu.php");
            }
    if ($FileError==0) {
      
    }else {
      $_SESSION['msg']="Veuiller choisir un fichier";
      header("Location: fichierEtu.php");
    }
}else {
  $_SESSION['msg']="Veuiller choisir un fichier";
  header("Location: fichierEtu.php");
}

$idsec=$_SESSION['IdSec'];
     $espaceEtu->query("INSERT INTO information (`Nom`,`Type`,`IdSec`) VALUES ('$FileName','$Typ','$idsec')");     
  
      $_SESSION['succes']="Enregistrement reussi !";
      header("location: info.php");
?>
