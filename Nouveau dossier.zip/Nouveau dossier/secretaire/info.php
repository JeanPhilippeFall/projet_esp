<?php
session_start();
include '../connexionBase.php';

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Ajouter etudiant</title>

    <!-- Bootstrap -->
    <link href="../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../Administrateur/css/animate.css">
    <link href="../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
              <div class="navbar-collapse collapse" >							
				<div class="menu" >
					<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
					<li role="presentation">
						<a href="Accueil.php" >Accueil</a></li>
						<li role="presentation"><a href="" >Etudiant</a>
						<ul class="soumenu">
							<li><a href="ajouterEtudiant/choixNiveau.php">Ajouter</a></li>
							
							<li><a href="afficherEtudiant/choixNiveau.php">Afficher</a>
							</li>
							</ul>
					</li>
					<li role="presentation">
						<a href="">Enseignant</a>
						<ul  class="soumenu">
						<li><a href="ajouterEnseignant/choixNiveau.php">Ajouter</a></li>
							
							<li><a href="afficherEnseignant/choixNiveau.php">Afficher</a></li>
						</ul>
					</li>
					<li role="presentation">
						<a href="classe.php" >Classe</a>
					</li>
          <li role="presentation">
            <a href="info.php" class="active" ">Information</a>
            
          </li>
					<li role="presentation">
						<a href="../deconnexion.php">Deconnexion</a>
					</li>	
						</ul>
					</div>
					
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
			
 			<div id="dep">
           <span style="color: white;">
            <?php
            if (isset($_SESSION['succes'])) {
               echo $_SESSION['succes'];
               unset($_SESSION['succes']);
            }
            if (isset($_SESSION['msg'])) {
               echo $_SESSION['msg'];
               unset($_SESSION['msg']);
            }

            ?></span>
        <form method="post" action="infoAjouter.php" enctype="multipart/form-data">
           
                <label> Libelle </label>
               <input type="texte" name="libelle" class="form-control"><br>
               <input type="file" name="fichier" class="form-control"><br>
             <input type="submit" name="ajouClass" value="Ajouter" class="btn btn-info">
       </form>
      </div>
      <a href="infoPub.php" style="position: absolute;
                  top:30%;
                  left: 15%;
      " ><input type="submit" name="infoPub" value="Information publiée" class="btn btn-info"></a>

			 <div class="p"></div>

		<?php// }?>
	
	
	
	
	
  </body>
</html>