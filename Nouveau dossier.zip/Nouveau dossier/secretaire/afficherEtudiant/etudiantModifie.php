<?php
session_start();
include '../../connexionBase.php';

  $etu=$espaceEtu->prepare("UPDATE etudiant SET Nom=:nm,Prenom=:prnm,DatNes=:datnes WHERE IdEtu=:idetu");
$rs2= $etu->execute(array(
			"nm"=> $_REQUEST['nm'],
			"prnm"=> $_REQUEST['prenm'],
			"datnes"=> $_REQUEST['datNes'],
			"idetu"=> $_SESSION['idetu']
				));
	$_SESSION['msg']=" Modification réussie !";
	header("location: afficherEtudiant.php");

?>