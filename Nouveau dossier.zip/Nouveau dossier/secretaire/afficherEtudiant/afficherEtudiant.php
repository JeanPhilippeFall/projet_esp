<?php
session_start();
include '../../connexionBase.php';
if (isset($_REQUEST['choixClasse'])) {
    if ($_REQUEST['choixClasse']=="") {
        $_SESSION['msg']="Choisir une clase";
        header("location: classe.php");
    }
      
    $_SESSION['idclass']=$_REQUEST['choixClasse'];
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Etudiant</title>

    <!-- Bootstrap -->
    <link href="../../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../Administrateur/css/animate.css">
    <link href="../../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="../Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
                    <li role="presentation">
                        <a href="../Accueil.php" >Accueil</a></li>
                        <li role="presentation"><a href="" class="active">Etudiant</a>
                        <ul class="soumenu">
                            <li><a href="../ajouterEtudiant/choixNiveau.php">Ajouter</a></li>
                            
                            <li><a href="choixNiveau.php">Afficher</a>
                            </li>
                            </ul>
                    </li>
                    <li role="presentation">
                        <a href="">Enseignant</a>
                        <ul  class="soumenu">
                        <li><a href="../ajouterEnseignant/choixNiveau.php">Ajouter</a></li>
                            
                            <li><a href="../afficherEnseignant/choixNiveau.php">Afficher</a></li>
                        </ul>
                    </li>
                    <li role="presentation">
                        <a href="../classe.php">Classe</a>
                    </li>
                    <li role="presentation">
                        <a href="../info.php ">Information</a>
            
                    </li>
                    <li role="presentation">
                        <a href="../../deconnexion.php">Deconnexion</a>
                    </li>   
                        </ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
			
 			<?php
              
 			$Etu=$espaceEtu->query("SELECT * FROM etudiant where IdClasse='".$_SESSION['idclass']."' ");

            $clas=$espaceEtu->query("SELECT * FROM classe where IdClasse='".$_SESSION['idclass']."' ");
              $rw=$clas->fetch();
               $_SESSION['class']=$rw['Nom'];
              ?>
     <span style="color: #65aaf0;
                   font-size: 25px;">
                   <?php
                   echo $_SESSION['class'];
                   ?>
         
     </span>
 			<div class="mov">
                <span style="color: green;
                            font-size: 25px;

                ">
                <?php
                    if (isset($_SESSION['sup'])) {
                       echo $_SESSION['sup'];
                       unset($_SESSION['sup']);
                    }
                    if (isset($_SESSION['msg'])) {
                       echo $_SESSION['msg'];
                       unset($_SESSION['msg']);
                    }
                ?></span>
 			 <table border="2" style="color: black;" class="table table-striped">
            <tr class="color">
            <th>Nom</th><th>Prenom</th><th>naissance</th><th>Action</th>
            </tr>
            <?php				
 		while($row=$Etu->fetch()){?>
	       <tr>
                <td><?php  echo $row['Nom'];?></td>
                <td> <?php echo $row['Prenom'];?></td>
                 <td><?php  echo $row['DatNes'];?></td>
                 <td> <a href="sup.php?idetu=<?php echo $row['IdEtu'];?>" ><img src="../../Administrateur/img/sup.jpg"> </a>
                    <a href="modif.php?idetu=<?php echo $row['IdEtu'];?>" ><img src="../../Administrateur/img/edit.jpg"></a>
                 </td>
            </tr>
		<?php }?></table>
      </div>
       
	
  </body>
</html>