<?php 
session_start();
include '../../connexionBase.php';
if (isset($_REQUEST['idetu'])) {
	$espaceEtu->query("DELETE FROM identifiant WHERE IdEtu='".$_REQUEST['idetu']."'");
	$espaceEtu->query("DELETE FROM absence WHERE IdEtu='".$_REQUEST['idetu']."'");
	$espaceEtu->query("DELETE FROM note WHERE IdEtu='".$_REQUEST['idetu']."'");
	$espaceEtu->query("DELETE FROM etudiant WHERE IdEtu='".$_REQUEST['idetu']."'");
	$_SESSION['sup']="Suppression reussie !";
	header("location: afficherEtudiant.php");
}else{
	header("location: afficherEtudiant.php");
}





 ?>