<?php
session_start();
include '../../connexionBase.php';
$_SESSION['idens']=$_REQUEST['idens'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Etudiant</title>

    <!-- Bootstrap -->
    <link href="../../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../Administrateur/css/animate.css">
    <link href="../../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="../Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
              <div class="navbar-collapse collapse" >							
				<div class="menu" >
					<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
					<li role="presentation">
						<a href="../Accueil.php" >Accueil</a></li>
						<li role="presentation"><a href="" >Etudiant</a>
						<ul class="soumenu">
							<li><a href="../ajouterEtudiant/choixNiveau.php">Ajouter</a></li>
							
							<li><a href="choixNiveau.php">Afficher</a>
							</li>
							</ul>
					</li>
					<li role="presentation">
						<a href="" class="active">Enseignant</a>
						<ul  class="soumenu">
						<li><a href="../ajouterEnseignant/choixNiveau.php">Ajouter</a></li>
							
							<li><a href="../afficherEnseignant/choixNiveau.php">Afficher</a></li>
						</ul>
					</li>
					<li role="presentation">
						<a href="../classe.php">Classe</a>
					</li>
					<li role="presentation">
                        <a href="../info.php ">Information</a>
            
                    </li>
					<li role="presentation">
						<a href="../../deconnexion.php">Deconnexion</a>
					</li>	
						</ul>
					</div>
					
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
			
 			<?php
                  

	

		$idclas=$espaceEtu->query("SELECT IdClasse FROM enseignantclasse where IdEns='".$_SESSION['idens']."' ");
                $row=$idclas->fetch();
                $_SESSION['IdClasse']=$row['IdClasse'];
                $class=$espaceEtu->query("SELECT * FROM classe where IdClasse='".$row['IdClasse']."' ");
                $row1=$class->fetch();

                $class=$espaceEtu->query("SELECT * FROM classe where IdDep='".$row1['IdDep']."' ");
                


                $ens=$espaceEtu->query("SELECT * FROM enseignant where IdEns='".$_SESSION['idens']."' ");
                $row2=$ens->fetch();

	?>
	<div id="dep" style="height: 55%;">
 		 	<form method="POST" action="enseignantModifie.php">
 		 		<label for="nm">Nom</label>
 		 			<input type="text" value="<?php echo $row2['Nom'];?>" name="nm"  class="form-control"><br>
 		 			<label for="prenm">Prenom</label>
 		 			<input type="text" value="<?php echo $row2['Prenom'];?>" name="prenm"  class="form-control">
 		 		<br>
 		 		<select name="clas" class="form-control" >
          <option value="">Classe</option>
         
          <?php
          
        while($classe=$class->fetch()){ 	
        	?>
				<option value="<?php echo $classe['IdClasse']; ?>" ><?php echo $classe['Nom'];?></option><?php
			 }  ?>
			</select>
			<input type="submit" name="enregistrer" value="Enregistrer"  class="btn btn-info">
			 
			
 		 	</form>
 		 	</div>
			 <div class="p"></div>

		<?php// }?>
	
	
	
	
	
  </body>
</html>