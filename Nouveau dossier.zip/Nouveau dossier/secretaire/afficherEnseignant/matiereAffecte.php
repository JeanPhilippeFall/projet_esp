<?php

session_start();
include '../../connexionBase.php';
$mat=$espaceEtu->query("SELECT * FROM ec WHERE Matiere='".$_REQUEST['mat']."'");

if (!($row=$mat->fetch())) {
	$ue=$espaceEtu->query("SELECT * FROM ue WHERE Nom='".$_REQUEST['ue']."'");
	if (!($rw=$ue->fetch())) {
		$u=$_REQUEST['ue'];
		$insert=$espaceEtu->query("INSERT INTO ue (`Nom`) VALUES ( '$u')");

}

	$select=$espaceEtu->query("SELECT * FROM ue WHERE Nom='".$_REQUEST['ue']."'");
	$ue=$select->fetch();
	$mat=$_REQUEST['mat'];
	$id=$ue['IdUe'];
	$id2=$_SESSION['idclass'];
	$mat=$espaceEtu->query("INSERT INTO ec (`Matiere`,`IdUe`,`IdClasse`) VALUES ('$mat','$id','$id2' )");
	
}
$mat=$espaceEtu->query("SELECT * FROM ec WHERE Matiere='".$_REQUEST['mat']."'");
$row=$mat->fetch();
	$m=$_SESSION['idens'];
	$n=$row['IdEc'];
	$ensEc=$espaceEtu->query("SELECT * FROM enseignantec WHERE IdEns='".$m."' and IdEc='".$n."'");
	if ($result=$ensEc->fetch()) {
		$_SESSION['mg']="Dejà affecté!";
	header("location: afficherEnseignant.php");
	}
$mat=$espaceEtu->query("INSERT INTO enseignantec (`IdEns`,`IdEc`) VALUES ('$m','$n')");
	$_SESSION['mg']="INSERTION REUSSIE";
	header("location: afficherEnseignant.php");
	


?>