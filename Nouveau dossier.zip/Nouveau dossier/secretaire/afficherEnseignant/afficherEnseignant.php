<?php
session_start();
include '../../connexionBase.php';
if (isset($_REQUEST['choixClasse'])) {
    if ($_REQUEST['choixClasse']=="") {
        $_SESSION['msg']="Choisir une classe";
        header("location: classe.php");
    }
      $_SESSION['idclass']=$_REQUEST['choixClasse'];
    
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Enseignant</title>

    <!-- Bootstrap -->
    <link href="../../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../Administrateur/css/animate.css">
    <link href="../../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="../Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
                    <li role="presentation">
                        <a href="../Accueil.php" >Accueil</a></li>
                        <li role="presentation"><a href="" >Etudiant</a>
                        <ul class="soumenu">
                            <li><a href="../ajouterEtudiant/choixNiveau.php">Ajouter</a></li>
                            
                            <li><a href="../afficherEtudiant/choixNiveau.php">Afficher</a>
                            </li>
                            </ul>
                    </li>
                    <li role="presentation">
                        <a href="" class="active">Enseignant</a>
                        <ul  class="soumenu">
                        <li><a href="../ajouterEnseignant/choixNiveau.php">Ajouter</a></li>
                            
                            <li><a href="choixNiveau.php">Afficher</a></li>
                        </ul>
                    </li>
                    <li role="presentation">
                        <a href="../classe.php">Classe</a>
                    </li>
                    <li role="presentation">
            <a href="../info.php ">Information</a>
            
          </li>
                    <li role="presentation">
                        <a href="../../deconnexion.php">Deconnexion</a>
                    </li>   
                        </ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
			
 			<?php
            $nm=$espaceEtu->query("SELECT Nom FROM departement where IdDep='".$_SESSION['dep']."' ");
            $rw=$nm->fetch();
             $_SESSION['nm']=$rw['Nom'];

             $Etu=$espaceEtu->query("SELECT * FROM classe where IdClasse='".$_SESSION['idclass']."' ");
               
               
                //$class=$espaceEtu->query('SELECT nom FROM classe');
              ?>

              <span style="color:#65aaf0 ;
                            font-size: 35px;
                            
                            "><?php
                    if (isset($_SESSION['nm'])) {
                       echo $_SESSION['nm'];
                       
                    }?><center>Liste des enseignants</center></span>
 			<div class="mov">
               
                
                <span style="color: green;
                            font-size: 25px;

                ">
                <?php
                    if (isset($_SESSION['mg'])) {
                       echo $_SESSION['mg'];
                       unset($_SESSION['mg']);
                    }
                    if (isset($_SESSION['sup'])) {
                       echo $_SESSION['sup'];
                       unset($_SESSION['sup']);
                    }
                    ?>
                    </span>
                    
 			 <table border="2" style="color: black;" class="table table-striped">
            <tr class="color">
            <th>Nom</th><th>Prenom</th><th>Classe</th><th>Matiere</th><th>Action</th><th>Matiere</th>
        </tr>
            <?php				
 		while($row=$Etu->fetch()){

               

            $Etu1=$espaceEtu->query("SELECT IdEns FROM enseignantClasse where IdClasse='".$_SESSION['idclass']."' ");
               while ($row1=$Etu1->fetch()) {
                
               

               $idec=$espaceEtu->query("SELECT IdEc FROM enseignantec where IdEns='".$row1['IdEns']."' ");
               

               $Etu2=$espaceEtu->query("SELECT * FROM enseignant where IdEns='".$row1['IdEns']."' ");
               $row2=$Etu2->fetch();

      ?>
	       <tr>
                <td><?php  echo $row2['Nom'];?></td>
                <td> <?php echo $row2['Prenom'];?></td>
                <td><?php  echo $row['Nom'];?></td>
                <td><?php $row3=$idec->fetch();
                $ec=$espaceEtu->query("SELECT * FROM ec where IdEc='".$row3['IdEc']."' "); 
                while($row4=$ec->fetch()){
               
                 echo $row4['Matiere']."<br>";
                $row3=$idec->fetch();
                $ec=$espaceEtu->query("SELECT * FROM ec where IdEc='".$row3['IdEc']."' "); 
                  }?></td>
                 
                 <td> <a href="sup.php?idens=<?php echo $row2['IdEns'];?>" ><img src="../../Administrateur/img/sup.jpg"></a>
                    <a href="modif.php?idens=<?php echo $row2['IdEns'];?>" ><img src="../../Administrateur/img/edit.jpg"></a>
                   
                 </td>
                 <td> <a href="affecterMatiere.php?idens=<?php echo $row2['IdEns'];?>" " style="background-color: #65aaf0;"> Affectation</a></td>
            </tr>
		<?php }
  }?></table>
      </div>
        
	
  </body>
</html>