<?php 
session_start();
include '../../connexionBase.php';
if (isset($_REQUEST['idens'])) {
	$espaceEtu->query("DELETE FROM enseignantclasse WHERE IdEns='".$_REQUEST['idens']."'");
	$espaceEtu->query("DELETE FROM enseignantec WHERE IdEns='".$_REQUEST['idens']."'");
	$espaceEtu->query("DELETE FROM identifiant WHERE IdEns='".$_REQUEST['idens']."'");
	$espaceEtu->query("DELETE FROM enseignant WHERE IdEns='".$_REQUEST['idens']."'");
	$_SESSION['sup']="Suppression reussie !";
	header("location: afficherEnseignant.php");
}else{
	header("location: afficherEnseignant.php");
}





 ?>