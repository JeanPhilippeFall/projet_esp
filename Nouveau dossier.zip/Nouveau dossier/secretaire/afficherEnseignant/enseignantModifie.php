<?php
session_start();
include '../../connexionBase.php';
if ($_REQUEST['enregistrer']) {
	$nom=$_REQUEST['nm'];
	$prenm=$_REQUEST['prenm'];
	$idclas=$_REQUEST['clas'];
}
$class=$espaceEtu->prepare("SELECT * FROM classe WHERE IdClasse=:id");
$rs1= $class->execute(array(
			"id"=> $idclas
				));
$ensclas=$espaceEtu->prepare("UPDATE enseignantclasse SET IdClasse=:id1 WHERE IdEns=:idens");
$rs2= $ensclas->execute(array(
			"id1"=> $idclas,
			"idens"=> $_SESSION['idens']
				));
  $ens=$espaceEtu->prepare("UPDATE enseignant SET Nom=:nom,Prenom=:prnm WHERE IdEns=:idens");
$rs2= $ens->execute(array(
			"nom"=> $nom,
			"prnm"=> $prenm,
			"idens"=> $_SESSION['idens']
				));
	$_SESSION['mg']=" Modification réussie !";
	header("location: afficherEnseignant.php");

?>