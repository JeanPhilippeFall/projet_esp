<?php
session_start();
include '../connexionBase.php';
if ($_REQUEST['enregistrer']) {
	$clas=$_REQUEST['clas'];
	$niv=$_REQUEST['niv'];

}
$class=$espaceEtu->prepare("UPDATE classe SET Nom=:nm  WHERE IdClasse=:id");
$rs1= $class->execute(array(
			"nm"=> $clas,
			"id"=> $_SESSION['IdClasse']
				));
  $ens=$espaceEtu->prepare("UPDATE niveau SET Nom=:nom WHERE Nom=:nm");
$rs2= $ens->execute(array(
			"nom"=> $niv,
			"nm"=> $_SESSION['Nom']
		
				));
	$_SESSION['mg']=" Modification réussie !";
	header("location: afficherClasse.php");

?>