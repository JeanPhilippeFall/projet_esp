<?php
  require('../fpdf17/fpdf.php');
  //A4 width :219mm
  //Default margin: 10mm chaque coté
  //Taille de la zone de texte 219-(10*2)=189mm
  //Ajout d'une page
  $pdf= new FPDF('P','mm','A3');
  $pdf->AddPage();
  //Set font 
  $pdf->setFont('Arial','B',12);
  //Cell('width,height,text,border,end of line, align')


try {
  $connexion= new PDO("mysql:host=localhost;dbname=gestionParc","root","");
  $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $sql="SELECT * From Vehicule";
  $sql2="SELECT * From Conducteur";
  $requete2=$connexion->query($sql2);
  $requete=$connexion->query($sql);
  //Entete du fichier pdf
  $pdf->Cell(280,7,'Vehicule',1,1,'C');
  $pdf->Cell(35,7,'immat',1,0);
  $pdf->Cell(35,7,'Date_service',1,0);
  $pdf->Cell(35,7,'Date_tech',1,0);
  $pdf->Cell(35,7,'Etat',1,0);
  $pdf->Cell(35,7,'Model',1,0);
  $pdf->Cell(35,7,'Marque',1,0);
  $pdf->Cell(35,7,'Conducteur',1,0);
  $pdf->Cell(35,7,'departement',1,1);

  while ($row=$requete->fetch()) {
    $row2=$requete2->fetch();
    $pdf->Cell(35,8,$row['Immat'],1,0);
    $pdf->Cell(35,8,$row['Date_service'],1,0);
    $pdf->Cell(35,8,$row['Date_tech'],1,0);
    $pdf->Cell(35,8,$row['Etat'],1,0);
    $pdf->Cell(35,8,$row['nomModele'],1,0);
    $pdf->Cell(35,8,$row['nomMarque'],1,0);
    $pdf->Cell(35,8,$row2['nom'],1,0);
    $pdf->Cell(35,8,$row['nomDepart'],1,1);
  }

  $pdf->Output();

} catch (PDOException $e) {
  die("Erreur:".$e->getMessage());
}

 ?>
