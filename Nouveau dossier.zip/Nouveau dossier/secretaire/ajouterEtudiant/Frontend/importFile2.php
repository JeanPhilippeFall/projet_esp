<?php
session_start();
include '../../../connexionBase.php';
$FileName=$_FILES["fichier"]["name"];
$FileError=$_FILES["fichier"]["error"];
if (isset($FileName)) {
    if ($FileError==0) {
      
    }else {
      $_SESSION['msg']="Veuiller choisir un fichier";
      header("Location: importFile.php");
    }
}else {
  $_SESSION['msg']="Veuiller choisir un fichier";
  header("Location: importFile.php");
}
require_once "../Classes/PHPExcel.php";

// Ouvrir un fichier Excel en lecture
#$objReader = PHPExcel_IOFactory::createReader('Excel2007');
$fichier=$FileName;
$objReader = PHPExcel_IOFactory::createReaderForFile($fichier);
$objPHPExcel = $objReader->load($fichier);
$sheet = $objPHPExcel->getActiveSheet() ;
$lastRow=$sheet->getHighestRow();


//Connection à la base de données gestionParc


  
  //Insertion des données
  for ($row=2; $row <=$lastRow ; $row++) {
    $cell1 = $sheet->getCell('A'.$row);
    $cell2= $sheet->getCell('B'.$row);
    $cell3= $sheet->getCell('C'.$row);
    $cell4= $sheet->getCell('D'.$row);
    $cell5= $sheet->getCell('E'.$row);
    $cell6= $sheet->getCell('F'.$row);
    $cell7= $sheet->getCell('G'.$row);

      $sql1="REPLACE INTO etudiant (`Nom`,`Prenom`,`Adresse`,`Tel`,`DatNes`,`IdClasse`,`IdNiv`) VALUES ('$cell1','$cell2','$cell3','$cell4','$cell5','$cell6','$cell7')";
      $espaceEtu->query($sql1);
      

  }

?>
