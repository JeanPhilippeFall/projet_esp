<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="../templates/materialize/css/materialize.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="importFile.css">
    <script type="text/javascript" src="jquery-3.3.1.min (1).js"></script>
    <script type="text/javascript" src="../templates/materialize/js/materialize.js"></script>
  </head>
  <body>
    <!-- <script type="text/javascript">
        $(document).ready(function() {
        $('select').material_select();
          });
    </script> -->
    <div id="contain">
          <form class="col s12" method="post" action="importFile.php" enctype="multipart/form-data">
              <div class="input-field col s6">
                <i class="material-icons prefix icon">account_circle</i>
                <input id="icon_prefix" type="text" class="validate" name="nom"  data-error="wrong" data-succes="right">
                <label for="icon_prefix">Nom</label>
              </div>
              <div class="input-field col s6">
                <i class="material-icons prefix icon">account_circle</i>
                <input id="icon_prefix" type="text" class="validate" name="prenom" data-error="wrong" data-succes="right">
                <label for="icon_prefix">Prenom</label>
              </div>
              <div class="input-field col s6">
                <i class="material-icons prefix icon">lock</i>
                <input id="icon_prefix" type="password" class="validate" name="passwd" data-error="wrong" data-succes="right">
                <label for="icon_prefix">Mot de Passe</label>
              </div>
              <button class="btn waves-effect waves-light color" type="submit" name="action">Se connecter
                <i class="material-icons right">send</i>
              </button>

          </form>


    </div>

  </body>
</html>
