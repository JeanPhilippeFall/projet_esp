CREATE TABLE Marque(nomMarque varchar(30));
alter table marque add constraint primary key(nomMarque); 
CREATE TABLE Modele(nomModel varchar(30),constraint pk_nomModel primary key(nomModel));
CREATE TABLE Conducteur(idConducteur int auto incremente ,nom varchar(30),
						prenom varchar(30),adresse varchar(50),
						constraint pk_idConducteur primary key(idConducteur));
CREATE TABLE Departement(nomDepart varchar(30));
CREATE TABLE Vehicule(Immat varchar(20),Date_service varchar(20),
					Date_tech varchar(20),Etat varchar(20),
					nomModele varchar(30),nomDepart varchar(30),
					nomMarque varchar(30),idConducteur int,
					constraint pk_immat primary key(immat),
					constraint fk_nomModel foreign key(nomModele) references Modele(nomModele) On DELETE SET NULL,
					constraint fk_nomMarque foreign key(nomMarque) references Marque(nomMarque )On DELETE SET NULL,
					constraint fk_nomdepart foreign key(nomDepart) references Departement(nomDepart)On DELETE SET NULL,
					constraint fk_idConducteur foreign key(idConducteur) references Conducteur(idConducteur)On DELETE SET NULL);
