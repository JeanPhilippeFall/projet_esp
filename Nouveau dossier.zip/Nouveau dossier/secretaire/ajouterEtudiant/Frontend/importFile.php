<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Import File</title>
    <link rel="stylesheet" href="../templates/materialize/css/materialize.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="importFile.css">
    <script type="text/javascript" src="jquery-3.3.1.min (1).js"></script>
    <script src="../templates/materialize/js/materialize.js" charset="utf-8"></script>
  </head>
  <body>
      <div id="header">
        <form action="../../../connexion.php">
          <input type="submit" name="" class="color" alt="Déconnexion" value="Deconnexion" >
        </form>
      </div>
      <div id="container">
        <form method="post" action="importFile2.php" enctype="multipart/form-data">
           <div class="file-field input-field ">
             <div class="btn color">
               <span>File</span>
               <input type="file" name="fichier" data-error="wrong" data-succes="right">
             </div>
             <div class="file-path-wrapper">
               <input class="file-path validate" type="text"  value="" >
             </div>
             <?php
             session_start();
             if(isset($_SESSION['msg'])){
             ?>
             <p class="error"><?php echo $_SESSION['msg'];?></p>
           <?php } unset($_SESSION['msg']);?>
           </div>
           <button class="btn waves-effect waves-light color" type="submit" name="action">
               <i class="material-icons right">send</i>
         </button>
       </form>
      </div>

      <?php
        // $nom=$_REQUEST['nom'];
        // $prenom=$_REQUEST['prenom'];
        // $passwd=$_REQUEST['passwd'];
        //
        // if ($nom!=null) {
        //   if ($prenom!=null) {
        //     if ($passwd!=null) {
        //       continue;
        //     }else {
        //       header("location: login.php");
        //     }
        //   }else {
        //     header("location: login.php");
        //   }
        // }else {
        //   header("location: login.php");
        // }

       ?>



  </body>
</html>
