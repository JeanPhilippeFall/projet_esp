<?php
session_start();
include '../../connexionBase.php';

$FileError=$_FILES["fichier"]["error"];
if (isset($_FILES['fichier']['name'])) {
  $extension = strtolower(substr($_FILES['fichier']['name'],-3));
    
            if ($extension == "csv") {
                move_uploaded_file($_FILES['fichier']['tmp_name'],"d/".$_FILES['fichier']['name']);
                 $FileName = "d/".$_FILES['fichier']['name'];
                
         
            }else{
              $_SESSION['msg']="Veuiller choisir un bon format";
               header("Location: fichierEtu.php");
            }
    if ($FileError==0) {
      
    }else {
      $_SESSION['msg']="Veuiller choisir un fichier";
      header("Location: fichierEtu.php");
    }
}else {
  $_SESSION['msg']="Veuiller choisir un fichier";
  header("Location: fichierEtu.php");
}
require_once "Classes/PHPExcel.php";

// Ouvrir un fichier Excel en lecture
#$objReader = PHPExcel_IOFactory::createReader('Excel2007');
$fichier=$FileName;
$objReader = PHPExcel_IOFactory::createReaderForFile($fichier);
$objPHPExcel = $objReader->load($fichier);
$sheet = $objPHPExcel->getActiveSheet() ;
$lastRow=$sheet->getHighestRow();


//Connection à la base de données gestionParc


  $IdNiv=$espaceEtu->query("SELECT IdNiv FROM classe where IdClasse='".$_SESSION['idclass']."' ");
      $row=$IdNiv->fetch();
        $niv=$row['IdNiv'];
        $class=$_SESSION['idclass'];

         
  //Insertion des données
  for ($row=2; $row <=$lastRow ; $row++) {
    $cell1 = $sheet->getCell('A'.$row);
    $cell2= $sheet->getCell('B'.$row);
    $cell3= $sheet->getCell('C'.$row);
    $cell4= $sheet->getCell('D'.$row);
    $cell5= $sheet->getCell('E'.$row);
    $cell6= $sheet->getCell('F'.$row);
    
    $Idetu=$espaceEtu->prepare("SELECT IdEtu FROM etudiant where nom=:nm and Prenom=:pr and DatNes=:dn ");
        $rs=$Idetu->execute(array(
                    "nm"=> $cell1,
                    "pr"=> $cell2,
                    "dn"=> $cell3
                      ));
        
       if (!($row1=$Idetu->fetch())) {
      
      $sql1="REPLACE INTO etudiant (`Nom`,`Prenom`,`DatNes`,`IdClasse`,`IdNiv`) VALUES ('$cell1','$cell2','$cell3','$class','$niv')";
      $espaceEtu->query($sql1);

        $Idetu1=$espaceEtu->prepare("SELECT IdEtu FROM etudiant where nom=:nm and Prenom=:pr and DatNes=:dn ");
        $rs=$Idetu1->execute(array(
                    "nm"=> $cell1,
                    "pr"=> $cell2,
                    "dn"=> $cell3
                      ));
        $row2=$Idetu1->fetch();
        $etu=$row2['IdEtu'];
      $sql2="REPLACE INTO identifiant (`Login`,`motDePasse`,`IdEtu`) VALUES ('$cell4','$cell5','$etu')";
      $espaceEtu->query($sql2);
     }  
  }
      $_SESSION['succes']="Enregistrement reussi !";
      header("location: fichierEtu.php");
?>
