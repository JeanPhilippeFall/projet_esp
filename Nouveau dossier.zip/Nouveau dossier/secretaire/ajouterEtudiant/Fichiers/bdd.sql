CREATE TABLE Marque(nomMarque varchar(30),constraint pkMarque primary key(nomMarque));
CREATE TABLE Conducteur(idConducteur int auto_increment,nom varchar(30),prenom varchar(50),adresse varchar(100),
                              constraint pk_Conducteur primary key(idConducteur));
CREATE TABLE ChefDepart(idChef int auto_increment, nom varchar(30), Prenom varchar(50), email varchar(60),
                          password varchar(60),adresse varchar(100), constraint pk_ChefDepart primary key(idChef) );
CREATE TABLE Departement(nomDepart varchar(30),idChef int, constraint pk_Departement primary key(nomDepart),
                              constraint fk_idChef foreign key(idChef) REFERENCES ChefDepart(idChef) on DELETE CASCADE);
CREATE TABLE Modele(nomModele varchar(30),nomMarque varchar(30), constraint pk_Modele primary key(nomModele),
                        constraint fk_nomMarque foreign key(nomMarque) REFERENCES Marque(nomMarque));
CREATE TABLE Vehicule(immat varchar(20),Date_service varchar(20),Date_tech varchar(20),Etat varchar(20),
                        nomModele varchar(30),nomDepart varchar(30), nomMarque varchar(30),idConducteur int,
                          constraint pk_Vehicule primary key(immat),constraint fk_nomModele foreign key(nomModele)
                            REFERENCES Modele(nomModele),constraint fk_nomMarque foreign key(nomMarque)
                              REFERENCES Marque(nomMarque),constraint fk_nomDepart foreign key(nomDepart)
                                REFERENCES Departement(nomDepart),constraint fk_idConducteur foreign key(idConducteur)
                                  REFERENCES Conducteur(idConducteur));
