<?php
session_start();
$FileName=$_FILES["fichier"]["name"];
$FileError=$_FILES["fichier"]["error"];
if (isset($FileName)) {
    if ($FileError==0) {
      if ($FileName=="fichier.csv") {
        echo "<h1>Enregistrement réussie</h1>";
      }else {
        $_SESSION['msg']="Télécharger le fichier ayant les données sur les véhicules";
        header("Location: importFile.php");
      }
    }else {
      $_SESSION['msg']="Veuiller choisir un fichier";
      header("Location: importFile.php");
    }
}else {
  $_SESSION['msg']="Veuiller choisir un fichier";
  header("Location: importFile.php");
}
require_once "../Classes/PHPExcel.php";

// Ouvrir un fichier Excel en lecture
#$objReader = PHPExcel_IOFactory::createReader('Excel2007');
$fichier="../Fichiers/fichier.csv";
$objReader = PHPExcel_IOFactory::createReaderForFile($fichier);
$objPHPExcel = $objReader->load($fichier);
$sheet = $objPHPExcel->getActiveSheet() ;
$lastRow=$sheet->getHighestRow();


//Connection à la base de données gestionParc

try {
  $connexion= new PDO("mysql:host=localhost;dbname=gestionParc","root","");
  $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //
  //Insertion des données
  for ($row=2; $row <=$lastRow ; $row++) {
    $cell1 = $sheet->getCell('A'.$row);
    $cell2= $sheet->getCell('B'.$row);
    $cell3= $sheet->getCell('C'.$row);
    $cell4= $sheet->getCell('D'.$row);
    $nomModele= $sheet->getCell('E'.$row);
    $nomMarque= $sheet->getCell('F'.$row);
    $nomDepart= $sheet->getCell('G'.$row);
    $nom= $sheet->getCell('H'.$row);
    $prenom= $sheet->getCell('I'.$row);
    $adresse= $sheet->getCell('J'.$row);
  //  echo $cell1->getValue()." ".$cell2->getValue()."  ".$cell3->getValue()."  ".$cell4->getValue()."<br><br>";
    $sql1="SELECT Immat FROM Vehicule";
    $requete=$connexion->query($sql1);
    //$resultat=$requete->fetchall();

      $sql2="REPLACE INTO Marque (`nomMarque`) VALUES ('$nomMarque')";
      $connexion->query($sql2);
      $sql1="REPLACE INTO Modele (`nomModele`) VALUES ('$nomModele')";
      $connexion->query($sql1);
      //$sql4="REPLACE INTO Conducteur (`nom`,`prenom`,`adresse`,) VALUES ('$nom','$prenom','$adresse')";
     // $connexion->query($sql4);
      $sql3="REPLACE INTO Departement (`nomDepart`) VALUES ('$nomDepart')";
      $connexion->query($sql3);
      $sql="REPLACE INTO Vehicule (`Immat`,`Date_service`,`Date_tech`,`Etat`,`nomModele`,`nomDepart`,`nomMarque`) VALUES
                  ('$cell1','$cell2','$cell3','$cell4','$nomModele','$nomDepart','$nomMarque')";
      $connexion->query($sql);
      

  }
  // echo "Inserttion réussie";

} catch (PDOException $e) {
  die("Erreur:".$e->getMessage());
}


// echo $sheet->getCell('A1')->getValue();
// Premiere facon d'acceder au contenu de cellules du classeur Excel
// $cell_1 = $sheet->getCell('A1') ;
// $cell_2 = $sheet->getCell('B1') ;
// $cell_3 = $sheet->getCell('C1') ;

//echo 'Value : '.$cell_1->getValue()."\r\n" ;
// echo 'Calculated Value : '.$cell_1->getCalculatedValue()."\r\n" ;
// echo 'Formatted Value : '.$cell_1->getFormattedValue()."\r\n" ;

//echo 'Value : '.$cell_2->getValue()."\r\n" ;
// echo 'Calculated Value : '.$cell_2->getCalculatedValue()."\r\n" ;
// echo 'Formatted Value : '.$cell_2->getFormattedValue()."\r\n" ;

//echo 'Value : '.$cell_3->getValue()."\r\n" ;
// echo 'Calculated Value : '.$cell_3->getCalculatedValue()."\r\n" ;
// echo 'Formatted Value : '.$cell_3->getFormattedValue()."\r\n" ;

// Deuxieme facon d'acceder au contenu de cellules du classeur Excel
// $cell_1 = $sheet->getCellByColumnAndRow(0, 1) ;
// $cell_2 = $sheet->getCellByColumnAndRow(1, 1) ;
// $cell_3 = $sheet->getCellByColumnAndRow(2, 1) ;
//
// echo 'Value : '.$cell_1->getValue()."\r\n" ;
// echo 'Calculated Value : '.$cell_1->getCalculatedValue()."\r\n" ;
// echo 'Formatted Value : '.$cell_1->getFormattedValue()."\r\n" ;
//
// echo 'Value : '.$cell_2->getValue()."\r\n" ;
// echo 'Calculated Value : '.$cell_2->getCalculatedValue()."\r\n" ;
// echo 'Formatted Value : '.$cell_2->getFormattedValue()."\r\n" ;
//
// echo 'Value : '.$cell_3->getValue()."\r\n" ;
// echo 'Calculated Value : '.$cell_3->getCalculatedValue()."\r\n" ;
// echo 'Formatted Value : '.$cell_3->getFormattedValue()."\r\n" ;
//
// // Cas d'une cellule au format date
// $cell = $sheet->getCell('A2') ;
//
// echo 'Date Value : '.$cell->getValue()."\r\n" ;
// echo 'Date Calculated Value : '.$cell->getCalculatedValue()."\r\n" ;
// echo 'Date Formatted Value : '.$cell->getFormattedValue()."\r\n" ;
// $timestamp = PHPExcel_Shared_Date::ExcelToPHP($cell->getValue()); // (Unix time)
// $date = date('Y-m-d', $timestamp); // AAAA-MM-DD (formatted date)
// echo 'Date AAAA-MM-DD : '.$date."\r\n" ;

?>
