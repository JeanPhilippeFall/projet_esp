<?php 
session_start();
include '../connexionBase.php';
if (isset($_REQUEST['idinfo'])) {
	$espaceEtu->query("DELETE FROM information WHERE IdInfo='".$_REQUEST['idinfo']."'");
	
	$_SESSION['sup']="Suppression reussie !";
	header("location: infoPub.php");
}else{
	header("location: infoPub.php");
}





 ?>