<?php 
session_start();
include '../connexionBase.php';
if (isset($_REQUEST['idclas'])) {
	$espaceEtu->query("DELETE FROM classe WHERE IdClasse='".$_REQUEST['idclas']."'");
	
	$_SESSION['sup']="Suppression réussie !";
	header("location: afficherClasse.php");
}else{
	header("location: afficherClasse.php");
}





 ?>