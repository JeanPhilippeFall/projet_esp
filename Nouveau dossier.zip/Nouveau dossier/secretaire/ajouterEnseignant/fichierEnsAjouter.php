<?php
session_start();
include '../../connexionBase.php';

$FileError=$_FILES["fichier"]["error"];
if (isset($_FILES['fichier']['name'])) {
  $extension = strtolower(substr($_FILES['fichier']['name'],-3));
    
            if ($extension == "csv") {
                move_uploaded_file($_FILES['fichier']['tmp_name'],"d/".$_FILES['fichier']['name']);
                 $FileName = "d/".$_FILES['fichier']['name'];
                
         
            }else{
                $_SESSION['msg']="Veuiller choisir un bon format";
                header("Location: fichierEtu.php");
                }
    if ($FileError==0) {
      
    }else {
      $_SESSION['msg']="Veuiller choisir un fichier";
      header("Location: fichierEtu.php");
    }
}else {
  $_SESSION['msg']="Veuiller choisir un fichier";
  header("Location: fichierEtu.php");
}
require_once "../ajouterEtudiant/Classes/PHPExcel.php";

// Ouvrir un fichier Excel en lecture
#$objReader = PHPExcel_IOFactory::createReader('Excel2007');
$fichier=$FileName;
$objReader = PHPExcel_IOFactory::createReaderForFile($fichier);
$objPHPExcel = $objReader->load($fichier);
$sheet = $objPHPExcel->getActiveSheet() ;
$lastRow=$sheet->getHighestRow();


//Connection à la base de données gestionParc


  
  //Insertion des données
  for ($row=2; $row <=$lastRow ; $row++) {
    $cell1 = $sheet->getCell('A'.$row);
    $cell2= $sheet->getCell('B'.$row);
    $cell3= $sheet->getCell('C'.$row);
    $cell4= $sheet->getCell('D'.$row);
    $cell5= $sheet->getCell('E'.$row); 
    $cell6= $sheet->getCell('F'.$row);
    
    $idclass=$_SESSION['idclass'];
    $ue=$espaceEtu->query("SELECT * FROM ue where Nom='".$cell6."'");
    if (!($rep1=$ue->fetch())) {
    	$espaceEtu->query("REPLACE INTO ue (`Nom`) VALUES ('$cell6')");
    	$ue=$espaceEtu->query("SELECT * FROM ue where Nom='".$cell6."'");
    }
    $idue=$rep1['IdUe'];

    $ec=$espaceEtu->prepare("SELECT IdEc FROM ec where Matiere=:nm and IdClasse=:clas ");
      $rs3=$ec->execute(array(
                    "nm"=> $cell5,
                    "clas"=> $idclass                    
                      ));

      if (!($rep=$ec->fetch())) {
       $espaceEtu->query("REPLACE INTO ec (`Matiere`,`IdUe`,`IdClasse`) VALUES ('$cell5','$idue','$idclass')");
       $ec=$espaceEtu->prepare("SELECT IdEc FROM ec where Matiere=:nm and IdClasse=:clas ");
      $rs3=$ec->execute(array(
                    "nm"=> $cell5,
                    "clas"=> $idclass                    
                      ));
      			$rep=$ec->fetch();
       }
      
      $idec=$rep['IdEc'];

    $ens=$espaceEtu->prepare("SELECT IdEns FROM enseignant WHERE Nom=:nm and  Prenom=:pr");

        $rs=$ens->execute(array(
                    "nm"=> $cell1,
                    "pr"=> $cell2                    
                      ));
        

      if (!($row=$ens->fetch())) {
      
    $espaceEtu->query("REPLACE INTO enseignant (`Nom`,`Prenom`) VALUES ('$cell1','$cell2')");
    $ens2=$espaceEtu->prepare("SELECT IdEns FROM enseignant WHERE Nom=:nm and  Prenom=:pr");

        $rs=$ens2->execute(array(
                    "nm"=> $cell1,
                    "pr"=> $cell2                    
                      ));
        $row=$ens2->fetch();
        
      $IdEns=$row['IdEns'];
      $espaceEtu->query("REPLACE INTO identifiant (`Login`,`motDePasse`,`IdEns`) VALUES ('$cell3','$cell4','$IdEns')");

        }
        $IdEns=$row['IdEns'];
        $ens3=$espaceEtu->query("SELECT * FROM enseignantclasse WHERE IdClasse='".$idclass."' and IdEns='".$IdEns."'");
        if (!($rsult=$ens3->fetch())) {
       $espaceEtu->query("INSERT INTO enseignantclasse (`IdEns`,`IdClasse`) VALUES('$IdEns','$idclass')");

       }
      

       $ensEc=$espaceEtu->query("SELECT * FROM enseignantec WHERE IdEns='".$IdEns."' and IdEc='".$idec."'");
        if (!($rsult2=$ensEc->fetch())) {
      $repEc=$espaceEtu->query("INSERT INTO enseignantec (`IdEns`,`IdEc`) VALUES('$IdEns','$idec')");
      }
      $_SESSION['succes']="Enregistrement reussi !";
      header("location: fichierEns.php");
  


}
      
      header("location: fichierEns.php");
?>
