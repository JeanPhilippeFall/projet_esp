<?php
session_start();
include '../connexionBase.php';

$FileError=$_FILES["fichier"]["error"];
if (isset($_FILES['fichier']['name'])) {
  $extension = strtolower(substr($_FILES['fichier']['name'],-3));
    
            if ($extension == "csv") {
                move_uploaded_file($_FILES['fichier']['tmp_name'],"d/".$_FILES['fichier']['name']);
                 $FileName = "d/".$_FILES['fichier']['name'];
                
         
            }else{
              $_SESSION['msg']="Veuiller choisir un bon format";
               header("Location: fichierEtu.php");
            }
    if ($FileError==0) {
      
    }else {
      $_SESSION['msg']="Veuiller choisir un fichier";
      header("Location: fichierEtu.php");
    }
}else {
  $_SESSION['msg']="Veuiller choisir un fichier";
  header("Location: fichierEtu.php");
}
require_once "ajouterEtudiant/Classes/PHPExcel.php";

// Ouvrir un fichier Excel en lecture
#$objReader = PHPExcel_IOFactory::createReader('Excel2007');
$fichier=$FileName;
$objReader = PHPExcel_IOFactory::createReaderForFile($fichier);
$objPHPExcel = $objReader->load($fichier);
$sheet = $objPHPExcel->getActiveSheet() ;
$lastRow=$sheet->getHighestRow();


//Connection à la base de données gestionParc


  $IdNiv=$espaceEtu->query("SELECT IdNiv FROM classe where IdClasse='".$_SESSION['idclass']."' ");
      $row=$IdNiv->fetch();
        $niv=$row['IdNiv'];
        $class=$_SESSION['idclass'];

         
  //Insertion des données
  for ($row=2; $row <=$lastRow ; $row++) {
    $cell1 = $sheet->getCell('A'.$row);
    $cell2= $sheet->getCell('B'.$row);
   
   $IdDep=$espaceEtu->query("SELECT IdDep FROM secretaire where IdSec='".$_SESSION['IdSec']."' ");
   $rw=$IdDep->fetch();

    $IdNiv=$espaceEtu->query("SELECT IdNiv FROM niveau where Nom='".$cell2."' ");
    if (!($row1=$IdNiv->fetch())) {
    $espaceEtu->query("REPLACE INTO niveau (`Nom`)VALUES ('$cell2')");
       
      }

      $Idniv2=$espaceEtu->query("SELECT IdNiv FROM niveau where Nom='".$cell2."' ");
      $row3=$Idniv2->fetch();

      $class=$espaceEtu->prepare("SELECT IdClasse FROM classe where Nom=:nm and IdDep=:dep ");
      $rs=$class->execute(array(
                    "nm"=> $cell1,
                    "dep"=> $rw['IdDep']
                   
                      ));
       if (!($row4=$class->fetch())){
      $niv=$row3['IdNiv'];
      $depart=$rw['IdDep'];
      $sql1="INSERT INTO classe (`Nom`,`IdNiv`,`IdDep`) VALUES ('$cell1','$niv','$depart')";
      $espaceEtu->query($sql1);
   }
        
     }  
  
      $_SESSION['succes']="Enregistrement reussi !";
      header("location: classe.php");
?>
