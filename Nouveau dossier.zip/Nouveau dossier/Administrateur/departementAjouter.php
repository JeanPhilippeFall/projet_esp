<?php
session_start();
include '../connexionBase.php';
if (isset($_REQUEST['dep'])) {
  $_SESSION['dep']=$_REQUEST['dep'];
}
if (isset($_SESSION['dep'])) {
  $dep=$espaceEtu->query("SELECT * FROM departement");
  $var=0;
  while ($r=$dep->fetch()) { 
    if ($_SESSION['dep']==$r['Nom']) {
      $var=$var+1;
    }
   
  }
  if ($var==0) {
    $d=$_SESSION['dep'];
  $espaceEtu->query("INSERT INTO departement (`Nom`) VALUES('$d')");
  $_SESSION['succes']="insertion reussie !";
  header("location: departement.php");
}else{
    $_SESSION['succes']="Departement existant !";
    header("location: departement.php");
}
}
?>