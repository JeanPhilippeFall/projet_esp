<?php
session_start();
include '../connexionBase.php';
	$iddep=$_GET['iddep'];
	$sup= $espaceEtu->query("DELETE FROM  departement WHERE iddep='".$iddep."' ");
 		$_SESSION['sup']="Suppression reussie.";

 	header("location: afficherDepartement.php");

?>