<?php
session_start();
include '../connexionBase.php';
if (isset($_REQUEST['ajoudep'])) {
  $_SESSION['ajoudep']=$_REQUEST['ajoudep'];
  $_SESSION['IdDep']=$_REQUEST['choixDepartement'];
  $_SESSION['nom']=$_REQUEST['nom'];
  $_SESSION['prenom']=$_REQUEST['prenom'];
  $_SESSION['login']=$_REQUEST['login'];
  $_SESSION['pwd']=$_REQUEST['pwd'];
}

  $sec=$espaceEtu->query("SELECT * FROM secretaire where Nom='".$_SESSION['nom']."' and Prenom='".$_SESSION['prenom']."' ");
 
  

  $rep=$espaceEtu->prepare("REPLACE INTO secretaire (`Nom`,`Prenom`,`IdDep`) VALUES(:nm,:pr,:dep)");
  $rs=$rep->execute(array(
                    "nm"=> $_SESSION['nom'],
                    "pr"=> $_SESSION['prenom'],
                    "dep"=> $_SESSION['IdDep']                  
                      ));
  $sec2=$espaceEtu->query("SELECT IdSec FROM secretaire where Nom='".$_SESSION['nom']."' and Prenom='".$_SESSION['prenom']."' ");
  
  $lg=$_SESSION['login'];
  $pwd=$_SESSION['pwd'];
  $id=$sec2->fetch();
  $idsec=$id['IdSec'];
  $espaceEtu->query("INSERT INTO identifiant (`Login`,`motDePasse`,`IdSec`) VALUES('$lg','$pwd','$idsec')");
  $_SESSION['succes']="insertion reussie !";
  header("location: secretaire.php");


?>