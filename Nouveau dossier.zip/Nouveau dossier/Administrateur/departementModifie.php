<?php
session_start();

	include '../connexionBase.php';
	
	$modif= $espaceEtu->prepare("UPDATE  departement SET Nom=:nm WHERE IdDep=:iddep ");
 	$rs=$modif->execute(array(
						'nm'=>$_REQUEST['nm'],
						'iddep'=>$_SESSION['iddep']
						
				));
 	
 	
 		$_SESSION['mg']="modification reussie.";
 	
 	header("location: afficherDepartement.php");


?>