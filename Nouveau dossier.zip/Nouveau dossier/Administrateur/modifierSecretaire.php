<?php
session_start();
include '../connexionBase.php';

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>ajouter note</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
	<link rel="stylesheet" type="text/css" href="css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
					<li role="presentation">
						<a href="Accueil.php" >Accueil</a></li>
					<li role="presentation">
                           <a href="secretaire.php" class="active">Secretaire</a>
                      </li>
                      <li role="presentation">
                          <a href="departement.php">Departement</a>
                      </li>
					<li role="presentation">
						<a href="../deconnexion.php">Deconnexion</a>
					</li>	
						</ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	<?php
		
		$idsec=$_GET['idsec'];
		$_SESSION['idsec']=$idsec;
		
	$sec=$espaceEtu->query("SELECT * FROM secretaire where IdSec='".$_SESSION['idsec']."' ");
                $nm=$sec->fetch();
                $dep=$espaceEtu->query("SELECT Nom FROM departement where IdDep='".$nm['IdDep']."' ");
                $dp=$dep->fetch();
                	$_SESSION['IdDep']=$nm['IdDep'];
	?>
	<div id="dep" style="height: 60%;">
 		 	<form method="POST" action="secretaireModifie.php">
 		 		<label for="nm">Nom</label>
 		 			<input type="text" value="<?php echo $nm['Nom'];?>" name="nm"  class="form-control"><br>
 		 			<label for="prenm">Prenom</label>
 		 			<input type="text" value="<?php echo $nm['Prenom'];?>" name="prenm"  class="form-control"><br>
 		 			<label for="dep">Departement</label>
 		 			<input type="text" value="<?php echo $dp['Nom'];?>" name="dep"  class="form-control"><br>
 		 			
			<input type="submit" name="modifier" value="Modifier"  class="btn btn-info">
			 
			
 		 	</form>
 		 	</div>
	<div class="p"></div>
  </body>
</html>