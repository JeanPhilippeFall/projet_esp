<?php
session_start();

	include '../connexionBase.php';
	
	$modif= $espaceEtu->prepare("UPDATE  departement SET Nom=:nm WHERE IdDep=:iddep ");
 	$rs=$modif->execute(array(
						'nm'=>$_REQUEST['dep'],
						'iddep'=>$_SESSION['IdDep']
						
				));
 	$modif= $espaceEtu->prepare("UPDATE  secretaire SET Nom=:nm,Prenom=:prnm WHERE IdSec=:idsec ");
 	$rs=$modif->execute(array(
						'nm'=>$_REQUEST['nm'],
						'prnm'=>$_REQUEST['prenm'],
						'idsec'=>$_SESSION['idsec']
						
				));
 	
 	
 		$_SESSION['mg']="modification reussie.";
 	
 	header("location: afficherSecretaire.php");


?>