<?php
session_start();
include '../connexionBase.php';
	$idsec=$_GET['idsec'];
	$supinfo= $espaceEtu->query("DELETE FROM  information WHERE IdSec='".$idsec."' ");
$sup= $espaceEtu->query("DELETE FROM  secretaire WHERE IdSec='".$idsec."' ");
 		$_SESSION['sup']="Suppression reussie.";

 	header("location: afficherSecretaire.php");

?>