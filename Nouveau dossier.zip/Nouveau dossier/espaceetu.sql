-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2018 at 12:22 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `espaceetu`
--

-- --------------------------------------------------------

--
-- Table structure for table `absence`
--

CREATE TABLE IF NOT EXISTS `absence` (
  `IdAbs` int(11) NOT NULL AUTO_INCREMENT,
  `IdSeance` int(11) NOT NULL,
  `IdEtu` int(11) NOT NULL,
  PRIMARY KEY (`IdAbs`),
  KEY `fk_IdEtu_Abs` (`IdEtu`),
  KEY `fk_IdSeance_Abs` (`IdSeance`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `absence`
--

INSERT INTO `absence` (`IdAbs`, `IdSeance`, `IdEtu`) VALUES
(4, 4, 52),
(8, 8, 52),
(9, 9, 57),
(10, 10, 55),
(11, 11, 55);

-- --------------------------------------------------------

--
-- Table structure for table `administrateur`
--

CREATE TABLE IF NOT EXISTS `administrateur` (
  `IdAdmin` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  `Prenom` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IdAdmin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `administrateur`
--

INSERT INTO `administrateur` (`IdAdmin`, `Nom`, `Prenom`) VALUES
(1, 'NDIAYE', 'Khadim');

-- --------------------------------------------------------

--
-- Table structure for table `classe`
--

CREATE TABLE IF NOT EXISTS `classe` (
  `IdClasse` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  `IdNiv` int(11) NOT NULL,
  `IdDep` int(11) NOT NULL,
  PRIMARY KEY (`IdClasse`),
  KEY `IdNiv` (`IdNiv`),
  KEY `IdDep` (`IdDep`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `classe`
--

INSERT INTO `classe` (`IdClasse`, `Nom`, `IdNiv`, `IdDep`) VALUES
(23, 'DUT1 TR', 1, 3),
(24, 'DUT1 info', 1, 3),
(25, 'Licence 1 TR', 6, 3),
(26, 'Licence 1 info', 6, 3),
(27, 'DUT2 TR', 4, 3),
(28, 'DUT2 info', 4, 3),
(30, 'Licence 2 info', 7, 3),
(31, 'Licence 3 TR', 8, 3),
(32, 'Licence 3 info', 8, 3),
(33, 'DIC 1 TR', 9, 3),
(34, 'DIC 1 info', 9, 3),
(35, 'DIC 2 TR', 10, 3),
(36, 'DIC 2 info', 10, 3),
(37, 'DIC 3 TR', 11, 3),
(38, 'DIC 3 info', 11, 3);

-- --------------------------------------------------------

--
-- Table structure for table `classeec`
--

CREATE TABLE IF NOT EXISTS `classeec` (
  `IdClasse` int(11) NOT NULL,
  `IdEc` int(11) NOT NULL,
  PRIMARY KEY (`IdClasse`,`IdEc`),
  KEY `fk_IdEc_classeec` (`IdEc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classeec`
--

INSERT INTO `classeec` (`IdClasse`, `IdEc`) VALUES
(23, 7),
(23, 8);

-- --------------------------------------------------------

--
-- Table structure for table `departement`
--

CREATE TABLE IF NOT EXISTS `departement` (
  `IdDep` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IdDep`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `departement`
--

INSERT INTO `departement` (`IdDep`, `Nom`) VALUES
(3, 'Genie informatique'),
(4, 'Genie Mecanique'),
(5, 'Genie Civil'),
(7, 'Gestion'),
(8, 'Genie Electrique'),
(9, 'GCBA');

-- --------------------------------------------------------

--
-- Table structure for table `ec`
--

CREATE TABLE IF NOT EXISTS `ec` (
  `IdEc` int(11) NOT NULL AUTO_INCREMENT,
  `Matiere` varchar(30) DEFAULT NULL,
  `IdUe` int(11) NOT NULL,
  `IdClasse` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdEc`),
  KEY `IdClasse` (`IdClasse`),
  KEY `fk_IdUe_EC` (`IdUe`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `ec`
--

INSERT INTO `ec` (`IdEc`, `Matiere`, `IdUe`, `IdClasse`) VALUES
(7, 'langage C', 1, 23),
(8, 'algo', 1, 23),
(9, 'Admin BD', 1, 23),
(19, 'pascal', 1, 23);

-- --------------------------------------------------------

--
-- Table structure for table `ecsemestre`
--

CREATE TABLE IF NOT EXISTS `ecsemestre` (
  `IdEc` int(11) NOT NULL,
  `IdSem` int(11) NOT NULL,
  PRIMARY KEY (`IdEc`,`IdSem`),
  KEY `fk_IdSem_ECSem` (`IdSem`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `enseignant`
--

CREATE TABLE IF NOT EXISTS `enseignant` (
  `IdEns` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  `Prenom` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IdEns`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `enseignant`
--

INSERT INTO `enseignant` (`IdEns`, `Nom`, `Prenom`) VALUES
(73, 'GUEYE', 'Mr'),
(75, 'Mrr', 'gueye'),
(79, 'NDIAYE', 'Samba');

-- --------------------------------------------------------

--
-- Table structure for table `enseignantclasse`
--

CREATE TABLE IF NOT EXISTS `enseignantclasse` (
  `IdEns` int(11) NOT NULL,
  `IdClasse` int(11) NOT NULL,
  PRIMARY KEY (`IdEns`,`IdClasse`),
  KEY `fk_IdClasse_enseignantClasse` (`IdClasse`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enseignantclasse`
--

INSERT INTO `enseignantclasse` (`IdEns`, `IdClasse`) VALUES
(73, 23),
(79, 23);

-- --------------------------------------------------------

--
-- Table structure for table `enseignantec`
--

CREATE TABLE IF NOT EXISTS `enseignantec` (
  `IdEns` int(11) NOT NULL,
  `IdEc` int(11) NOT NULL,
  PRIMARY KEY (`IdEns`,`IdEc`),
  KEY `fk_IdEc_enseignantec` (`IdEc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enseignantec`
--

INSERT INTO `enseignantec` (`IdEns`, `IdEc`) VALUES
(79, 7),
(73, 8),
(79, 9);

-- --------------------------------------------------------

--
-- Table structure for table `etudiant`
--

CREATE TABLE IF NOT EXISTS `etudiant` (
  `IdEtu` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  `Prenom` varchar(30) DEFAULT NULL,
  `DatNes` varchar(100) NOT NULL,
  `Adresse` varchar(30) DEFAULT NULL,
  `Tel` varchar(30) DEFAULT NULL,
  `IdClasse` int(11) NOT NULL,
  `IdNiv` int(11) NOT NULL,
  PRIMARY KEY (`IdEtu`),
  KEY `fk_IdClasse_Etu` (`IdClasse`),
  KEY `fk_IdNiv_Etu` (`IdNiv`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `etudiant`
--

INSERT INTO `etudiant` (`IdEtu`, `Nom`, `Prenom`, `DatNes`, `Adresse`, `Tel`, `IdClasse`, `IdNiv`) VALUES
(52, 'NDIAYE', 'Abdou', '1996-02-01', NULL, NULL, 23, 1),
(55, 'GUEYE', 'Aliou', '1996-02-01', NULL, NULL, 23, 1),
(56, 'LY', 'Modou', '1996-05-04', NULL, NULL, 23, 1),
(57, 'Camara', 'bassirou', '1996-05-04', NULL, NULL, 23, 1);

-- --------------------------------------------------------

--
-- Table structure for table `identifiant`
--

CREATE TABLE IF NOT EXISTS `identifiant` (
  `IdId` int(11) NOT NULL AUTO_INCREMENT,
  `Login` varchar(30) NOT NULL,
  `motDePasse` varchar(100) NOT NULL,
  `IdAdmin` int(11) DEFAULT NULL,
  `IdEtu` int(11) DEFAULT NULL,
  `IdEns` int(11) DEFAULT NULL,
  `IdSec` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdId`),
  KEY `fk_IdAdmin_Administrateur` (`IdAdmin`),
  KEY `fk_IdEtu_Etudiant` (`IdEtu`),
  KEY `fk_IdSec_Secretaire` (`IdSec`),
  KEY `fk_IdEns_Enseignant` (`IdEns`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=115 ;

--
-- Dumping data for table `identifiant`
--

INSERT INTO `identifiant` (`IdId`, `Login`, `motDePasse`, `IdAdmin`, `IdEtu`, `IdEns`, `IdSec`) VALUES
(7, 'Secretaire', 'passer', NULL, NULL, NULL, 9),
(101, 'M.gueye', 'passer', NULL, NULL, 75, NULL),
(102, 'admin', 'passer', 1, NULL, NULL, NULL),
(106, 'maty.faye', 'passer', NULL, NULL, NULL, NULL),
(109, 'Enseignant1', 'passer', NULL, NULL, 79, NULL),
(111, 'binta.sambe', 'passer', NULL, NULL, NULL, 9),
(112, 'etudiant1', 'passer', NULL, 55, NULL, NULL),
(113, 'etudiant2', 'passer', NULL, 56, NULL, NULL),
(114, 'etudiant3', 'passer', NULL, 57, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE IF NOT EXISTS `information` (
  `IdInfo` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  `Type` varchar(30) DEFAULT NULL,
  `IdSec` int(11) NOT NULL,
  PRIMARY KEY (`IdInfo`),
  KEY `fk_IdSec_Info` (`IdSec`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`IdInfo`, `Nom`, `Type`, `IdSec`) VALUES
(5, 'd/EspaceEtudiant.pdf', 'information', 9);

-- --------------------------------------------------------

--
-- Table structure for table `niveau`
--

CREATE TABLE IF NOT EXISTS `niveau` (
  `IdNiv` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IdNiv`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `niveau`
--

INSERT INTO `niveau` (`IdNiv`, `Nom`) VALUES
(1, 'DUT1'),
(4, 'DUT2'),
(5, 'DIC1'),
(6, 'Licence 1'),
(7, 'Licence 2'),
(8, 'Licence 3'),
(9, 'DIC 1'),
(10, 'DIC 2'),
(11, 'DIC 3');

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE IF NOT EXISTS `note` (
  `IdNote` int(11) NOT NULL AUTO_INCREMENT,
  `Cc` double DEFAULT NULL,
  `Ds` double DEFAULT NULL,
  `Tp` double DEFAULT NULL,
  `IdEc` int(11) NOT NULL,
  `IdEtu` int(11) NOT NULL,
  `IdSem` int(11) NOT NULL,
  PRIMARY KEY (`IdNote`),
  KEY `fk_IdEc_Note` (`IdEc`),
  KEY `fk_IdEtu_Note` (`IdEtu`),
  KEY `IdSem` (`IdSem`),
  KEY `IdSem_2` (`IdSem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`IdNote`, `Cc`, `Ds`, `Tp`, `IdEc`, `IdEtu`, `IdSem`) VALUES
(5, 16, 17, 19, 9, 52, 1),
(8, 19, 16, 19, 7, 55, 1);

-- --------------------------------------------------------

--
-- Table structure for table `seancedecours`
--

CREATE TABLE IF NOT EXISTS `seancedecours` (
  `IdSeance` int(11) NOT NULL AUTO_INCREMENT,
  `dat` varchar(100) NOT NULL,
  `IdEc` int(11) NOT NULL,
  PRIMARY KEY (`IdSeance`),
  KEY `IdEc` (`IdEc`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `seancedecours`
--

INSERT INTO `seancedecours` (`IdSeance`, `dat`, `IdEc`) VALUES
(1, '2018-06-07', 9),
(4, '2018-06-06', 9),
(5, '2018-04-04', 9),
(6, '2018-01-11', 9),
(7, '2018-02-08', 9),
(8, '2018-04-05', 7),
(9, '2018-06-09', 9),
(10, '2018-06-08', 7),
(11, '2017-12-06', 9);

-- --------------------------------------------------------

--
-- Table structure for table `secretaire`
--

CREATE TABLE IF NOT EXISTS `secretaire` (
  `IdSec` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) DEFAULT NULL,
  `Prenom` varchar(30) DEFAULT NULL,
  `IdDep` int(11) NOT NULL,
  PRIMARY KEY (`IdSec`),
  KEY `fk_idDep_sec` (`IdDep`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `secretaire`
--

INSERT INTO `secretaire` (`IdSec`, `Nom`, `Prenom`, `IdDep`) VALUES
(9, 'SAMBE', 'Binta', 3);

-- --------------------------------------------------------

--
-- Table structure for table `semestre`
--

CREATE TABLE IF NOT EXISTS `semestre` (
  `IdSem` int(11) NOT NULL AUTO_INCREMENT,
  `NomSemestre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IdSem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `semestre`
--

INSERT INTO `semestre` (`IdSem`, `NomSemestre`) VALUES
(1, 'Semestre 1'),
(2, 'Semestre 2');

-- --------------------------------------------------------

--
-- Table structure for table `ue`
--

CREATE TABLE IF NOT EXISTS `ue` (
  `IdUe` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(100) NOT NULL,
  PRIMARY KEY (`IdUe`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ue`
--

INSERT INTO `ue` (`IdUe`, `Nom`) VALUES
(1, 'Informatique'),
(2, 'Methematique'),
(3, 'kkkk'),
(4, 'ktt');

-- --------------------------------------------------------

--
-- Table structure for table `ueniveau`
--

CREATE TABLE IF NOT EXISTS `ueniveau` (
  `IdUe` int(11) NOT NULL,
  `IdNiv` int(11) NOT NULL,
  PRIMARY KEY (`IdUe`,`IdNiv`),
  KEY `fk_IdNiv_UeNiveau` (`IdNiv`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `absence`
--
ALTER TABLE `absence`
  ADD CONSTRAINT `fk_IdEtu_Abs` FOREIGN KEY (`IdEtu`) REFERENCES `etudiant` (`IdEtu`),
  ADD CONSTRAINT `fk_IdSeance_Abs` FOREIGN KEY (`IdSeance`) REFERENCES `seancedecours` (`IdSeance`);

--
-- Constraints for table `classe`
--
ALTER TABLE `classe`
  ADD CONSTRAINT `fk_idDep_Classe` FOREIGN KEY (`IdDep`) REFERENCES `departement` (`IdDep`),
  ADD CONSTRAINT `fk_IdNIv_classe` FOREIGN KEY (`IdNiv`) REFERENCES `niveau` (`idNiv`) ON UPDATE CASCADE;

--
-- Constraints for table `classeec`
--
ALTER TABLE `classeec`
  ADD CONSTRAINT `fk_Idclasse_classeec` FOREIGN KEY (`IdClasse`) REFERENCES `classe` (`IdClasse`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_IdEc_classeec` FOREIGN KEY (`IdEc`) REFERENCES `ec` (`IdEc`) ON UPDATE CASCADE;

--
-- Constraints for table `ec`
--
ALTER TABLE `ec`
  ADD CONSTRAINT `fk_IdClasse_ec` FOREIGN KEY (`IdClasse`) REFERENCES `classe` (`IdClasse`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_IdUe_EC` FOREIGN KEY (`IdUe`) REFERENCES `ue` (`IdUe`);

--
-- Constraints for table `ecsemestre`
--
ALTER TABLE `ecsemestre`
  ADD CONSTRAINT `fk_IdEc_ECSem` FOREIGN KEY (`IdEc`) REFERENCES `ec` (`IdEc`),
  ADD CONSTRAINT `fk_IdSem_ECSem` FOREIGN KEY (`IdSem`) REFERENCES `semestre` (`IdSem`);

--
-- Constraints for table `enseignantclasse`
--
ALTER TABLE `enseignantclasse`
  ADD CONSTRAINT `fk_IdClasse_enseignantClasse` FOREIGN KEY (`IdClasse`) REFERENCES `classe` (`IdClasse`),
  ADD CONSTRAINT `fk_IdEns_enseignantClasse` FOREIGN KEY (`IdEns`) REFERENCES `enseignant` (`IdEns`);

--
-- Constraints for table `enseignantec`
--
ALTER TABLE `enseignantec`
  ADD CONSTRAINT `fk_IdEc_enseignantec` FOREIGN KEY (`IdEc`) REFERENCES `ec` (`IdEc`),
  ADD CONSTRAINT `fk_IdEns_enseignantec` FOREIGN KEY (`IdEns`) REFERENCES `enseignant` (`IdEns`);

--
-- Constraints for table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `fk_IdClasse_Etu` FOREIGN KEY (`IdClasse`) REFERENCES `classe` (`IdClasse`),
  ADD CONSTRAINT `fk_IdNiv_Etu` FOREIGN KEY (`IdNiv`) REFERENCES `niveau` (`idNiv`);

--
-- Constraints for table `identifiant`
--
ALTER TABLE `identifiant`
  ADD CONSTRAINT `fk_IdAdmin_Administrateur` FOREIGN KEY (`IdAdmin`) REFERENCES `administrateur` (`IdAdmin`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_IdEns_Enseignant` FOREIGN KEY (`IdEns`) REFERENCES `enseignant` (`IdEns`) ON UPDATE SET NULL,
  ADD CONSTRAINT `fk_IdEtu_Etudiant` FOREIGN KEY (`IdEtu`) REFERENCES `etudiant` (`IdEtu`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_IdSec_Secretaire` FOREIGN KEY (`IdSec`) REFERENCES `secretaire` (`IdSec`) ON DELETE SET NULL;

--
-- Constraints for table `information`
--
ALTER TABLE `information`
  ADD CONSTRAINT `fk_IdSec_Info` FOREIGN KEY (`IdSec`) REFERENCES `secretaire` (`IdSec`);

--
-- Constraints for table `note`
--
ALTER TABLE `note`
  ADD CONSTRAINT `fk_IdEc_Note` FOREIGN KEY (`IdEc`) REFERENCES `ec` (`IdEc`),
  ADD CONSTRAINT `fk_IdEtu_Note` FOREIGN KEY (`IdEtu`) REFERENCES `etudiant` (`IdEtu`),
  ADD CONSTRAINT `fk_IdSem_note` FOREIGN KEY (`IdSem`) REFERENCES `semestre` (`IdSem`);

--
-- Constraints for table `secretaire`
--
ALTER TABLE `secretaire`
  ADD CONSTRAINT `fk_idDep_sec` FOREIGN KEY (`IdDep`) REFERENCES `departement` (`IdDep`);

--
-- Constraints for table `ueniveau`
--
ALTER TABLE `ueniveau`
  ADD CONSTRAINT `fk_IdNiv_UeNiveau` FOREIGN KEY (`IdNiv`) REFERENCES `niveau` (`idNiv`),
  ADD CONSTRAINT `fk_IdUe_niv` FOREIGN KEY (`IdUe`) REFERENCES `ue` (`IdUe`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
