<?php
session_start();

	include '../../connexionBase.php';
	if (isset($_REQUEST['dat'])) {
		$_SESSION['dat']=$_REQUEST['dat'];
	}
	$modif= $espaceEtu->prepare("UPDATE  seancedecours SET dat=:dt WHERE IdSeance=:IdSeance ");
 	$rs=$modif->execute(array(
 						'dt'=>$_SESSION['dat'],
						'IdSeance'=>$_SESSION['IdSeance']
						
				));
 	
 		$_SESSION['insert']="modification reussie.";
 	
 	header("location: afficheEleveAbsence.php");


?>