<?php
session_start();
include '../../connexionBase.php';
	$IdEtu=$_GET['IdEtu'];
	$IdSeance=$_GET['IdSeance'];
               echo $IdSeance; 
	$sup= $espaceEtu->query("DELETE FROM  absence WHERE IdEtu='".$IdEtu."' and IdSeance='".$IdSeance."' ");
	

	
 		$_SESSION['sup']="Suppression reussie.";
 	
 	header("location: afficheEleveAbsence.php");

?>