<?php

session_start();
echo $_REQUEST['cc'];

?>