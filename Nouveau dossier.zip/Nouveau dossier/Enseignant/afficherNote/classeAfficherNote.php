<?php
session_start();


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Note</title>

    <!-- Bootstrap -->
    <link href="../../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../Administrateur/css/animate.css">
    <link href="../../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="../Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
              <div class="navbar-collapse collapse">							
				<div class="menu">
					<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
					<li role="presentation">
						<a href="../Accueil.php" >Accueil</a></li>
						<li role="presentation"><a href="" class="active">Note</a>
						<ul class="soumenu">
							<li><a href="../ajouterNote/choixClasseNote.php">Ajouter</a></li>
							
							<li><a href="../afficherNote/classeAfficherNote.php">Afficher</a>
							</li>
							</ul>
					</li>
					<li role="presentation">
						<a href="">Absence</a>
						<ul  class="soumenu">
						<li><a href="../ajouterAbsence/choixClasseAbsence.php">Ajouter</a></li>
							
							<li><a href="../afficherAbsence/classeAfficherAbsence.php">Afficher</a></li>
						</ul>
					</li>
					<li role="presentation">
						<a href="../../deconnexion.php">Deconnexion</a>
					</li>	
						</ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
			<?php
			
			include '../../connexionBase.php';
             $idEns=$espaceEtu->prepare("SELECT IdClasse FROM enseignantclasse where IdEns=:IdEns");
			$rs= $idEns->execute(array(
				           	"IdEns"=> $_SESSION['IdEns']
				           	
				           		));
				$row=$idEns->fetch();

				$Deptmt=$espaceEtu->query("SELECT Nom FROM departement where IdDep IN (SELECT IdDep FROM classe where IdClasse='".$row['IdClasse']."')");
				
				$Class=$espaceEtu->query("SELECT Nom,IdClasse FROM classe where IdClasse IN (SELECT IdClasse FROM enseignantclasse where IdEns='".$_SESSION['IdEns']."' )");
					
			
 			
      
 			//$class=$espaceEtu->query('SELECT nom FROM classe');
 				

 				
 		//foreach($rsultEtu as $row){?>
 		<div id="dep" class="dep">
 			<span style="font-size: 17px; color: white;">
 			<?php
 			if (isset($_SESSION['msg'])) {
 				echo $_SESSION['msg'];
 				unset($_SESSION['msg']);
 			}?>
 			</span>
 		 	<form method="POST" action="afficheEleveNote.php">
 		 		<p >
          
 		 			<select name="choixDepartement" class="form-control">
            <option value="">Departement</option>
          <?php
          while($row1=$Deptmt->fetch()){ ?>
					<option value="<?php echo $row1['Nom']; ?>" ><?php echo $row1['Nom'];  }  ?></option>
				</select><br>
 		 		<select name="choixClasse" class="form-control" >
          <option value="">Classe</option>
         
          <?php
          
        while($row3=$Class->fetch()){ 
        		
        	?>
				<option value="<?php echo $row3['IdClasse']; ?>" ><?php echo $row3['Nom'];?></option><?php
			 }  ?>
			</select> <br>
			<input type="submit" class="btn btn-info" name="choix" value="Valider">
			   </p>
         <?php
         if (isset($_SESSION['erreur'])) {
           echo $_SESSION['erreur'];
           unset($_SESSION['erreur']);
         }?>
			
 		 	</form>
 		 	</div>
			 <div class="p"></div>
			
		<?php// }?>
	
	
	
	
	
  </body>
</html>