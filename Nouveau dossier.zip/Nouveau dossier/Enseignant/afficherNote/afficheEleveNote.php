<?php 
session_start();
include '../../connexionBase.php';
if (isset($_REQUEST['choixClasse'])&&isset($_REQUEST['choixDepartement'])) {
    if ($_REQUEST['choixClasse']==""||$_REQUEST['choixDepartement']=="") {
        $_SESSION['msg']="Choisir un departement et une classe";
        header("location: classeAfficherNote.php");
    }
    $_SESSION['IdClasse']=$_REQUEST['choixClasse'];
 }   
    

 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <script type="text/javascript">
        
        function numeroLigne()
{
   
    
              
       
            var cc= document.getElementById("cpt").innerHTML;
                        // Transmet la variable valeur_id dans le input hidden de la page fournisseur.php
                        document.getElementById("cc").value= cc;          
                
    
        
}
    </script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Afficher note</title>

    <!-- Bootstrap -->
    <link href="../../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../Administrateur/css/animate.css">
    <link href="../../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="../Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
                    <li role="presentation">
                        <a href="../Accueil.php" >Accueil</a></li>
                        <li role="presentation"><a href="" class="active">Note</a>
                        <ul class="soumenu">
                            <li><a href="../ajouterNote/choixClasseNote.php">Ajouter</a></li>
                            
                            <li><a href="../afficherNote/classeAfficherNote.php">Afficher</a>
                            </li>
                            </ul>
                    </li>
                    <li role="presentation">
                        <a href="">Absence</a>
                        <ul  class="soumenu">
                        <li><a href="../ajouterAbsence/choixClasseAbsence.php">Ajouter</a></li>
                            
                            <li><a href="../afficherAbsence/classeAfficherAbsence.php">Afficher</a></li>
                        </ul>
                    </li>
                    <li role="presentation">
                        <a href="../../deconnexion.php">Deconnexion</a>
                    </li>   
                        </ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
			
 			<?php
            
            
            
 			$class=$espaceEtu->query("SELECT * FROM classe where IdClasse='".$_SESSION['IdClasse']."' ");
              $row1=$class->fetch();

                $dep=$espaceEtu->query("SELECT Nom FROM departement where IdDep='".$row1['IdDep']."' ");
                    $rw=$dep->fetch();

                $Etu=$espaceEtu->query("SELECT * FROM etudiant where IdClasse='".$_SESSION['IdClasse']."' order by Nom");

              ?>
              <span class="span">
                  <?php 
                    echo $rw['Nom'];
                  ?>
              </span>
 			<div class="mov" >
            
                <span class="span" ">
            <?php
            if (isset($_SESSION['insert'])) {
                echo $_SESSION['insert'];
                unset($_SESSION['insert']);
            }?>
            </span>    
 			 <table  border="2" style="color: black;" class="table table-striped">
            <tr style="background-color: #65aaf0;">
            <th >Nom</th><th>Prenom</th><th>naissance</th><th>Matiere</th><th>CC</th><th>DS</th><th>TP</th><th>Action</th></tr>
            <?php				
 		while($row=$Etu->fetch()){
                $note=$espaceEtu->query("SELECT * FROM note where IdEtu='".$row['IdEtu']."' ");
                $not=$note->fetch();
                $ec=$espaceEtu->prepare("SELECT Matiere FROM ec where IdEc=:idec and IdClasse=:idclas ");
                $rs= $ec->execute(array(
                            "idec"=> $not['IdEc'],
                            "idclas"=> $_SESSION['IdClasse']
                                ));
                $Ec1=$ec->fetch();
            ?>
	       <tr>
                <td ><?php echo $row['Nom'];?></td>
                <td> <?php echo $row['Prenom'];?></td>
                 <td><?php  echo $row['DatNes'];?></td>
                 <td><?php  echo $Ec1['Matiere'];?></td>
                 <td><?php  echo $not['Cc'];?></td>
                 <td ><?php  echo $not['Ds'];?></td>
                 <td ><?php  echo $not['Tp'];?></td>
                 <td >
                    <a href="modifierNote.php?IdEtu=<?php echo ($not['IdEtu']);?>">
                     <img src="../../Administrateur/img/edit.jpg"></a>
                <a href="SupprimerNote.php?IdEtu=<?php echo ($not['IdEtu']);?>">
                     <img src="../../Administrateur/img/sup.jpg"></a>
                 </td>
            </tr>
		<?php }?></table>
    </div>
    <?php
                if (isset($_SESSION['sup'])) {
                    echo $_SESSION['sup'];
                    unset($_SESSION['sup']);
                }
             ?>
        <div class="p"></div>

  </body>
</html>