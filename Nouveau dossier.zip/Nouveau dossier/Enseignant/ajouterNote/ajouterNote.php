<?php
session_start();
include '../../connexionBase.php';
if (isset($_GET['idetu'])) {
	$_SESSION['idetu']=$_GET['idetu'];
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>ajouter note</title>

    <!-- Bootstrap -->
    <link href="../../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../Administrateur/css/animate.css">
    <link href="../../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="../Accueil.php"><h1>ESP</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist" id="menu-demo2" >
					<li role="presentation">
						<a href="../Accueil.php" >Accueil</a></li>
						<li role="presentation"><a href="" class="active">Note</a>
						<ul class="soumenu">
							<li><a href="../ajouterNote/choixClasseNote.php">Ajouter</a></li>
							
							<li><a href="../afficherNote/classeAfficherNote.php">Afficher</a>
							</li>
							</ul>
					</li>
					<li role="presentation">
						<a href="">Absence</a>
						<ul  class="soumenu">
						<li><a href="../ajouterAbsence/choixClasseAbsence.php">Ajouter</a></li>
							
							<li><a href="../afficherAbsence/classeAfficherAbsence.php">Afficher</a></li>
						</ul>
					</li>
					<li role="presentation">
						<a href="../../deconnexion.php">Deconnexion</a>
					</li>	
						</ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	<?php
		
		
		$idClas=$espaceEtu->query("SELECT IdClasse FROM etudiant where IdEtu='".$_SESSION['idetu']."' ");
		$r=$idClas->fetch();

 			
 			$Mat1=$espaceEtu->query("SELECT IdEc FROM enseignantec where IdEns='".$_SESSION['IdEns']."' ");
 			
 			
 			$sem=$espaceEtu->query("SELECT * FROM semestre");
 			
 			?>
				
			
 	
	<div id="dept" >
		<span style="font-size: 17px; color: white;"><?php
				if (isset($_SESSION['insertion'])) {
					echo $_SESSION['insertion'];
					unset($_SESSION['insertion']);
				}
				if (isset($_SESSION['nomComplet'])) {
					echo $_SESSION['nomComplet']."<br>";
					unset($_SESSION['nomComplet']);
				}
				if (isset($_SESSION['note'])) {
					echo $_SESSION['note'];
					unset($_SESSION['note']);
				}
				?>
				</span>
		<form method="POST" action="noteAjoute.php">
 		 		<p >
 		 	<select name="choixSemestre" class="form-control">
            <option value="">Semestre</option>
          <?php
          while($row3=$sem->fetch()){
          		?>
					<option value="<?php echo $row3['NomSemestre']; ?>" ><?php echo $row3['NomSemestre'];  ?></option><?php }  ?>
				</select><br><br>
          
 		 			<select name="choixMatiere" class="form-control">
            <option value="">Matiere</option>
          <?php
          while($row2=$Mat1->fetch()){
          		$Mat=$espaceEtu->prepare("SELECT Matiere FROM ec where IdEc=:IdEc and IdClasse=:idclasse");
 			$rs= $Mat->execute(array(
				           	"IdEc"=> $row2['IdEc'],
				           	"idclasse"=> $r['IdClasse']
				           	
				           		));
 			$row1=$Mat->fetch();

           ?>
					<option value="<?php echo $row1['Matiere']; ?>" ><?php echo $row1['Matiere'];  ?></option><?php }  ?>
				</select><br><br>
 		 		<select name="choixEvaluation" class="form-control" >
          <option value="">Evaluation</option>
				
				<option value="Cc" >Cc</option>
				<option value="Ds" >Ds</option>
				<option value="Tp" >Tp</option>
				
				
			</select> <br>
			<input type="number" class="form-control" name="note" value="" placeholder="Note >=0 ET Note <=20"><br>
			<input type="submit" class="btn btn-info" name="choix" value="Valider">
			   </p>
			</form>
         <?php
         if (isset($_SESSION['erreur'])) {
           echo $_SESSION['erreur'];
           unset($_SESSION['erreur']);
         }?>
			
 		 	
 		 	</div>
	<div class="p"></div>
  </body>
</html>