﻿<?php
session_start();
include '../connexionBase.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Mes Notes</title>

    <!-- Bootstrap -->
    <link href="../Administrateur/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../Administrateur/css/font-awesome.min.css">
	<link rel="stylesheet" href="../Administrateur/css/animate.css">
	<link href="../Administrateur/css/animate.min.css" rel="stylesheet"> 
	<link href="../Administrateur/css/style.css" rel="stylesheet" />	
	<link rel="stylesheet" type="text/css" href="../Administrateur/css/own.css">
	<link rel="stylesheet" type="text/css" href="../Administrateur/css/note.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body bgcolor="#77B5FE">	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="index.php"><h1>Mon Compte</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation"><a href="index.php">Accueil</a></li>
							<li role="presentation"><a href="#" class="active">Mes notes</a></li>
							<li role="presentation"><a href="edt.html"> emploi du temps</a></li>
							
							<li role="presentation"><a href="absence.php">Mes absences</a></li>
							<li role="presentation">
								<a href="info.php">Information</a>
									</li>
							<li role="presentation"><a href="../deconnexion.php">Déconnexion</a></li>						
						</ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	<?php
	$log=$_SESSION['log'];
	$requete1=$espaceEtu->prepare("SELECT IdEtu FROM identifiant WHERE login = :login ");
	$requete1->execute(array(":login" => $log));
	$resultat=$requete1->fetch();
	$id=$resultat['IdEtu'];
	
	$requete2=$espaceEtu->prepare("SELECT Tp,IdEc, Cc, Ds FROM note WHERE IdEtu = :idetu");
	$requete2->execute(array(":idetu" => $id));
	?>
		
			
			<div class="mov">
		<table border="2" style="color: black;" class="table table-striped">
			<tr style="background-color: #65aaf0;">
				<th>TP</th>
				<th>Contrôle</th>
				<th>Devoir</th>
				<th>Matière</th>
				<th>Ue</th>
			</tr>
			<?php 
			$_SESSION['noteIndispo']="note disponible !";
			
			while ($data=$requete2->fetch()) {
				$_SESSION['noteDispo']="Voici vos notes disponibles pour le moment";
				$intituleId=$data['IdEc'];
				$requete3=$espaceEtu->prepare("SELECT Matiere, IdUe FROM ec WHERE IdEc = :intituleId");
				$requete3->execute(array(":intituleId" => $intituleId));
				$intitule_result=$requete3->fetch();
				$ue = $intitule_result['IdUe'];
				$requete4 = $espaceEtu->prepare("SELECT Nom FROM ue WHERE IdUe = :ue");
				$requete4->execute(array(":ue" => $ue));
				$intitule_ue=$requete4->fetch();
				echo "<tr>";
				echo "<td>".$data['Tp']."</td>";
				echo "<td>".$data['Cc']."</td>";
				echo "<td>".$data['Ds']."</td>";
				echo "<td>".$intitule_result['Matiere']."</td>";
				echo "<td>".$intitule_ue['Nom']."</td>";
				echo "</tr>";
			}?>
		
		</table>
		</div>
		<span style="color:#65aaf0 ;
                            font-size: 25px;
                            position: absolute;
                            top: 20%;

                            "><?php
				if (!isset($_SESSION['noteDispo'])) {
					echo $_SESSION['noteIndispo'];
				}else{
					echo $_SESSION['noteDispo'];
				}?>
				</span>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/wow.min.js"></script>
	<script>
	wow = new WOW(
	 {
	
		}	) 
		.init();
	</script>	
  </body>
</html>