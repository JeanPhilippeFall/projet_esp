
<?php
session_start();
include '../connexionBase.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Mes absences</title>

    <!-- Bootstrap -->
    <link href="../Administrateur/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../Administrateur/css/font-awesome.min.css">
	<link rel="stylesheet" href="../Administrateur/css/animate.css">
	<link href="../Administrateur/css/animate.min.css" rel="stylesheet"> 
	<link href="../Administrateur/css/style.css" rel="stylesheet" />	
	<link rel="stylesheet" type="text/css" href="../Administrateur/css/own.css">
	<link rel="stylesheet" type="text/css" href="../Administrateur/css/note.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="index.php"><h1>Mon Compte</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation"><a href="index.php">Accueil</a></li>
							<li role="presentation"><a href="note.php">Mes notes</a></li>
							<li role="presentation"><a href="edt.html"> emploi du temps</a></li>
							
							<li role="presentation"><a href="#" class="active">Mes absences</a></li>
							<li role="presentation">
								<a href="info.php">Information</a>
									</li>
							<li role="presentation"><a href="../deconnexion.php">Déconnexion</a></li>						
						</ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->			
	<?php
	$log=$_SESSION['log'];
	$requete1=$espaceEtu->prepare('SELECT IdEtu FROM identifiant WHERE login = :log');
	$requete1->execute(array(":log" => $log));
	$resultat=$requete1->fetch();
	$id=$resultat['IdEtu'];
	$requete2=$espaceEtu->prepare("SELECT * FROM absence WHERE IdEtu = :idetu");
	$requete2->execute(array(":idetu" => $id));
	?>

		<p  style="color:#65aaf0 ;
                            font-size: 25px;
                            position: absolute;
                            top: 20%;
                            "> Mes Absences </p>
		<div class="mov">
		<table border="2" style="color: black;" class="table table-striped">
			<tr style="background-color: #65aaf0;">
				
				<th>Date</th>
				<th>Matière</th>
			</tr>
			<?php
			$requete3=$espaceEtu->prepare("SELECT IdAbs, IdSeance FROM absence WHERE IdEtu = :idetu");
			$requete3->execute(array(":idetu" => $id)); 
			
			while ($data=$requete3->fetch()) {
				$requete4 = $espaceEtu->prepare("SELECT dat, IdEc FROM seancedecours WHERE IdSeance = :idseance");
				$requete4->execute(array(":idseance" => $data['IdSeance']));
				$resultat2=$requete4->fetch();
				$requete5 = $espaceEtu->prepare("SELECT Matiere FROM ec WHERE IdEc = :idec");
				$requete5 -> execute(array(":idec" => $resultat2['IdEc']));
				$resultat3=$requete5->fetch();
				echo "<tr>";
		
				echo "<td>".$resultat2['dat']."</td>";
				echo "<td>".$resultat3['Matiere']."</td>";	
				echo "</tr>";
			}
	?></table>
</div>
	
	
	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/wow.min.js"></script>
	<script>
	wow = new WOW(
	 {
	
		}	) 
		.init();
	</script>	
  </body>
</html>