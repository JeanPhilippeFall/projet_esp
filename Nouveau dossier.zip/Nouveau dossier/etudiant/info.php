﻿<?php
session_start();
include '../connexionBase.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Mes Notes</title>

    <!-- Bootstrap -->
    <link href="../Administrateur/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Administrateur/css/font-awesome.min.css">
    <link rel="stylesheet" href="../Administrateur/css/animate.css">
    <link href="../Administrateur/css/animate.min.css" rel="stylesheet"> 
    <link href="../Administrateur/css/style.css" rel="stylesheet" />   
    <link rel="stylesheet" type="text/css" href="../Administrateur/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body bgcolor="#77B5FE">	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="index.php"><h1>Mon Compte</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation"><a href="index.php">Accueil</a></li>
							<li role="presentation"><a href="note.php" >Mes notes</a></li>
							<li role="presentation"><a href="edt.html"> emploi du temps</a></li>
							
							<li role="presentation"><a href="absence.php">Mes absences</a></li>
							<li role="presentation">
								<a href="" class="active">Information</a>
									</li>
							<li role="presentation"><a href="../deconnexion.php">Déconnexion</a></li>						
						</ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	<?php

	$class=$espaceEtu->query("SELECT IdClasse FROM etudiant WHERE IdEtu ='".$_SESSION['IdEtu']."' ");
		$idclas=$class->fetch();

	$dep=$espaceEtu->query("SELECT IdDep FROM classe WHERE IdClasse ='".$idclas['IdClasse']."' ");
	$iddep=$dep->fetch();

	$sec=$espaceEtu->query("SELECT IdSec FROM secretaire WHERE IdDep ='".$iddep['IdDep']."' ");
	$idsec=$sec->fetch();

	$sec=$idsec['IdSec'];
	$requete=$espaceEtu->query("SELECT * FROM information WHERE IdSec ='".$sec."' ");
	
	?>
		
			<p style="position: absolute;
						left: 35%;
						top: 20%;
						font-size: 35px;
			"> Information(s) disponible(s) </p>
			<div class="mov">
		<table class="table table-striped"  border="2" style="color: black;">
			<tr style="background-color: #65aaf0;">
				<th>Libelle</th>
				<th>Information</th>
				
			</tr>
			<?php 
			
			while ($data=$requete->fetch()) {
				?>
				<tr>
				<td><?php echo $data['Type']; ?></td>
				<td><a href="../secretaire/<?php echo $data['Nom']; ?>"><img src="../Administrateur/img/pdf.jpg"></a></td>
				</tr>
			<?php }
		
			?>
	
	
		
		</table>
		</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/wow.min.js"></script>
	<script>
	wow = new WOW(
	 {
	
		}	) 
		.init();
	</script>	
  </body>
</html>