
<?php
session_start();
include '../connexionBase.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Mon Compte Etudiant</title>

    <!-- Bootstrap -->
    <link href="../Administrateur/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../Administrateur/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link href="../Administrateur/css/animate.min.css" rel="stylesheet"> 
	<link href="../Administrateur/css/style.css" rel="stylesheet" />	
	<link rel="stylesheet" type="text/css" href="../Administrateur/css/own.css">
	<link rel="stylesheet" type="text/css" href="../Administrateur/css/css.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-default navbar-static-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                   <div class="navbar-brand">
						<a href="#"><h1>Etudiant</h1></a>
					</div>
                </div>				
                <div class="navbar-collapse collapse">							
					<div class="menu">
						<ul class="nav nav-tabs" role="tablist" id="menu-demo2">
							<li role="presentation"><a href="#" class="active">Accueil</a></li>
							<li role="presentation"><a href="note.php">Mes notes</a></li>
							
							<li role="presentation"><a href="edt.html"> emploi du temps</a></li>
							<li role="presentation">
								<a href="absence.php">Mes absences</a></li>
							<li role="presentation">
								<a href="info.php">Information</a>
									</li>
							<li role="presentation"><a href="../deconnexion.php">Déconnexion</a></li>						
						</ul>
					</div>
				</div>		
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
	<div class="slider">		
		<div id="about-slider">
			<div id="carousel-slider" class="carousel slide" data-ride="carousel">
				<!-- Indicators -->
				<ol class="carousel-indicators visible-xs">
					<li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
					<li data-target="#carousel-slider" data-slide-to="1"></li>
					<li data-target="#carousel-slider" data-slide-to="2"></li>
				</ol>

				<div class="carousel-inner">
					<div class="item active">						
						<img src="img/1.jpg" class="img-responsive" alt="" id="img_own"> 
						
				    </div>
			
				    <div class="item">
						<img src="img/3.jpg" class="img-responsive" alt="" id="img_own"> 
						
				    </div> 
				    <div class="item">
						<img src="img/5.jpg" class="img-responsive" alt="" id="img_own"> 
						
					</div> 
					<div class="item">
							<img src="img/6.jpg" class="img-responsive" alt="" id="img_own"> 
							
					</div>
				
				<a class="left carousel-control hidden-xs" href="#carousel-slider" data-slide="prev">
					<i class="fa fa-angle-left"></i> 
				</a>
				
				<a class=" right carousel-control hidden-xs"href="#carousel-slider" data-slide="next">
					<i class="fa fa-angle-right"></i> 
				</a>
			</div> <!--/#carousel-slider-->
		</div><!--/#about-slider-->
	</div><!--/#slider-->
	
	<div class="sub-footer">
		<div class="container">
			<div class="social-icon">
				<div class="col-md-4">
					<ul class="social-network">
						<li><a href="https://www.facebook.com/espdakar/?ref=br_rs" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https://twitter.com/esp_dakar" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="https://fr.linkedin.com/company/ecolesup%C3%A9rieurepolytechniquededakar?trk=ppro_cprof" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
					</ul>	
				</div>
			</div>
			
			<div class="col-md-4 col-md-offset-4">
				<div class="copyright">
					&copy; CRENT-2018 <a target="_blank" href="http://www.esp.sn" title="Site web de l'Ecole Supérieure Polytechnique">ESP-Dakar</a>.Tous droits réservés.
				</br>
					<?php 
					//session_start();
					$test=$_SESSION['choix'];
					echo "Vous vous connectez en tant que ".$test;
?>
				</div>
                <!-- 
                    All links in the footer should remain intact. 
                    Licenseing information is available at: http://bootstraptaste.com/license/
                    You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Day
                -->
			</div>						
		</div>				
	</div>
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/wow.min.js"></script>
	<script>
	wow = new WOW(
	 {
	
		}	) 
		.init();
	</script>	
  </body>
</html>